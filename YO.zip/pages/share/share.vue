<template>
	<view class="share-container">
		<!-- 顶部区域 -->
		<view class="header">
			<view class="title">分享识别结果</view>
			<view class="subtitle">让更多人了解林业害虫识别</view>
		</view>

		<!-- 内容预览区 -->
		<view class="preview-container">
			<image class="preview-image" :src="sharedData.imageUrl || '/static/images/15637.jpg'" mode="aspectFit"></image>
			<view class="preview-text">
				<view class="preview-title">害虫识别结果</view>
				<view class="preview-desc">检测到 {{sharedData.detectedCount || 0}} 个害虫</view>
			</view>
		</view>

		<!-- 识别结果展示 -->
		<view v-if="sharedData.results && sharedData.results.length > 0" class="results-container">
			<view class="section-title">识别结果</view>
			<view v-for="(result, index) in sharedData.results" :key="index" class="result-item">
				<view class="result-name">{{result.chinese_name || result.name}}</view>
				<view class="result-confidence">置信度: {{(result.confidence * 100).toFixed(1)}}%</view>
			</view>
		</view>

		<!-- 防治建议摘要 -->
		<view v-if="sharedData.preventionSuggestions && sharedData.preventionSuggestions.length > 0" class="suggestions-container">
			<view class="section-title">防治建议摘要</view>
			<view class="suggestion-summary">
				<view v-for="(suggestion, index) in displayedSuggestions" :key="index" class="suggestion-item">
					{{suggestion}}
				</view>
			</view>
		</view>

		<!-- 分享方式 -->
		<view class="share-methods">
			<view class="section-title">选择分享方式</view>
			<view class="share-buttons">
				<view class="share-button" @click="shareToSocial('weixin')">
					<view class="icon-circle wechat">
						<image src="/static/wenchat.png" mode="aspectFit" class="icon-image"></image>
					</view>
					<text>微信</text>
				</view>
				<view class="share-button" @click="shareToSocial('weixinFriend')">
					<view class="icon-circle moments">
						<image src="/static/moments.png" mode="aspectFit" class="icon-image"></image>
					</view>
					<text>朋友圈</text>
				</view>
				<view class="share-button" @click="shareToSocial('qq')">
					<view class="icon-circle qq">
						<image src="/static/qq.png" mode="aspectFit" class="icon-image"></image>
					</view>
					<text>QQ</text>
				</view>
				<view class="share-button" @click="shareToSocial('weibo')">
					<view class="icon-circle weibo">
						<image src="/static/weibo.png" mode="aspectFit" class="icon-image"></image>
					</view>
					<text>微博</text>
				</view>
			</view>
		</view>

		<!-- 链接分享 -->
		<view class="link-share">
			<view class="section-title">分享链接</view>
			<view class="link-container">
				<input class="link-input" :value="shareLink" disabled />
				<button class="copy-btn" @click="copyLink">复制</button>
			</view>
		</view>

		<!-- 二维码分享 -->
		<view class="qrcode-share">
			<view class="section-title">二维码分享</view>
			<view class="qrcode-container">
				<image class="qrcode-image" src="/static/qrcode.png" mode="aspectFit"></image>
				<button class="save-btn" @click="saveQrcode">保存二维码</button>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				shareLink: 'https://example.com/forest-pest-identifier',
				shareTitle: '林业害虫识别结果',
				shareContent: '快速识别常见林业害虫，提供专业防治方法，保护森林健康！',
				shareImageUrl: '/static/share-preview.png',
				sharedData: {
					imageUrl: '',
					results: [],
					detectedCount: 0,
					preventionSuggestions: []
				}
			}
		},
		computed: {
			// 只显示前3条防治建议
			displayedSuggestions() {
				if (!this.sharedData.preventionSuggestions) return [];

				// 过滤出列表项（通常以数字开头）
				const listItems = this.sharedData.preventionSuggestions.filter(item =>
					/^\d+\./.test(item) || item.startsWith('•') || item.startsWith('-')
				);

				// 如果没有列表项，返回前3条建议
				if (listItems.length === 0) {
					return this.sharedData.preventionSuggestions.slice(0, 3);
				}

				// 返回前3条列表项
				return listItems.slice(0, 3);
			}
		},
		onLoad(options) {
			// 接收从detail页面传递过来的数据
			if (options.data) {
				try {
					const decodedData = JSON.parse(decodeURIComponent(options.data));
					console.log('接收到的分享数据:', decodedData);

					this.sharedData = decodedData;

					// 更新分享内容
					if (this.sharedData.results && this.sharedData.results.length > 0) {
						const pestNames = this.sharedData.results.map(r => r.chinese_name || r.name).join('、');
						this.shareContent = `我使用林业害虫识别助手识别出了${pestNames}，快来了解防治方法！`;
						this.shareTitle = `林业害虫识别结果：${pestNames}`;
					}

					// 如果有图片，更新分享图片
					if (this.sharedData.imageUrl) {
						this.shareImageUrl = this.sharedData.imageUrl;
					}

				} catch (e) {
					console.error('解析分享数据失败:', e);
					uni.showToast({
						title: '数据加载失败',
						icon: 'none'
					});
				}
			}
		},
		methods: {
			// 社交平台分享
			shareToSocial(platform) {
				// 检查环境是否支持分享
				// #ifdef APP-PLUS
				uni.share({
					provider: platform,
					scene: platform === 'weixin' ? 'WXSceneSession' : platform === 'weixinFriend' ? 'WXSceneTimeline' : '',
					type: 0,
					title: this.shareTitle,
					summary: this.shareContent,
					imageUrl: this.shareImageUrl,
					href: this.shareLink,
					success: (res) => {
						uni.showToast({
							title: '分享成功',
							icon: 'success'
						});
					},
					fail: (err) => {
						uni.showToast({
							title: '分享失败',
							icon: 'none'
						});
						console.error('分享失败:', err);
					}
				});
				// #endif

				// #ifdef H5 || MP
				uni.showModal({
					title: '提示',
					content: '当前环境不支持直接分享，请复制链接手动分享',
					showCancel: false
				});
				// #endif
			},

			// 复制分享链接
			copyLink() {
				uni.setClipboardData({
					data: this.shareLink,
					success: () => {
						uni.showToast({
							title: '链接已复制',
							icon: 'success'
						});
					}
				});
			},

			// 保存二维码到相册
			saveQrcode() {
				// #ifdef APP-PLUS
				uni.saveImageToPhotosAlbum({
					filePath: '/static/qrcode.png',
					success: () => {
						uni.showToast({
							title: '二维码已保存',
							icon: 'success'
						});
					},
					fail: (err) => {
						uni.showModal({
							title: '保存失败',
							content: '请检查是否授予相册权限',
							showCancel: false
						});
					}
				});
				// #endif

				// #ifdef H5 || MP
				uni.showModal({
					title: '提示',
					content: '请长按二维码图片保存',
					showCancel: false
				});
				// #endif
			}
		}
	}
</script>

<style>
	.share-container {
		padding: 30rpx;
		background-color: #f8f8f8;
		min-height: 100vh;
	}

	.header {
		text-align: center;
		margin-bottom: 40rpx;
		padding-top: 20rpx;
	}

	.title {
		font-size: 36rpx;
		font-weight: bold;
		color: #0AA344;
		margin-bottom: 10rpx;
	}

	.subtitle {
		font-size: 24rpx;
		color: #666;
	}

	.preview-container {
		background-color: #FFFFFF;
		border-radius: 16rpx;
		padding: 30rpx;
		margin-bottom: 40rpx;
		display: flex;
		flex-direction: column;
		align-items: center;
		box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
	}

	.preview-image {
		width: 300rpx;
		height: 300rpx;
		margin-bottom: 20rpx;
		border-radius: 8rpx;
	}

	.preview-text {
		text-align: center;
	}

	.preview-title {
		font-size: 32rpx;
		font-weight: bold;
		color: #333;
		margin-bottom: 10rpx;
	}

	.preview-desc {
		font-size: 24rpx;
		color: #666;
	}

	.results-container, .suggestions-container {
		background-color: #FFFFFF;
		border-radius: 16rpx;
		padding: 30rpx;
		margin-bottom: 40rpx;
		box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
	}

	.result-item {
		padding: 15rpx 0;
		border-bottom: 1px solid #f0f0f0;
	}

	.result-item:last-child {
		border-bottom: none;
	}

	.result-name {
		font-size: 28rpx;
		font-weight: bold;
		color: #333;
	}

	.result-confidence {
		font-size: 24rpx;
		color: #666;
		margin-top: 5rpx;
	}

	.suggestion-summary {
		padding: 10rpx 0;
	}

	.suggestion-item {
		font-size: 26rpx;
		color: #333;
		padding: 10rpx 0;
		line-height: 1.5;
	}

	.section-title {
		font-size: 28rpx;
		font-weight: bold;
		color: #333;
		margin-bottom: 20rpx;
	}

	.share-methods {
		background-color: #FFFFFF;
		border-radius: 16rpx;
		padding: 30rpx;
		margin-bottom: 40rpx;
		box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
	}

	.share-buttons {
		display: flex;
		justify-content: space-around;
		flex-wrap: wrap;
	}

	.share-button {
		display: flex;
		flex-direction: column;
		align-items: center;
		width: 25%;
		margin-bottom: 20rpx;
	}

	.icon-circle {
		width: 100rpx;
		height: 100rpx;
		border-radius: 50%;
		display: flex;
		justify-content: center;
		align-items: center;
		margin-bottom: 10rpx;
	}

	.icon-image {
		width: 60rpx;
		height: 60rpx;
	}

	.wechat {
		background-color:#FFFFFF;
	}

	.moments {
		background-color: #FFFFFF;
	}

	.qq {
		background-color: #FFFFFF;
	}

	.weibo {
		background-color: #FFFFFF;
	}

	.link-share {
		background-color: #FFFFFF;
		border-radius: 16rpx;
		padding: 30rpx;
		margin-bottom: 40rpx;
		box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
	}

	.link-container {
		display: flex;
		align-items: center;
	}

	.link-input {
		flex: 1;
		background-color: #F0F0F0;
		border-radius: 8rpx;
		padding: 15rpx;
		font-size: 24rpx;
		color: #666;
	}

	.copy-btn {
		width: 150rpx;
		height: 70rpx;
		line-height: 70rpx;
		background-color: #0AA344;
		color: #FFFFFF;
		font-size: 26rpx;
		margin-left: 20rpx;
		border-radius: 8rpx;
	}

	.qrcode-share {
		background-color: #FFFFFF;
		border-radius: 16rpx;
		padding: 30rpx;
		margin-bottom: 40rpx;
		box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
	}

	.qrcode-container {
		display: flex;
		flex-direction: column;
		align-items: center;
	}

	.qrcode-image {
		width: 300rpx;
		height: 300rpx;
		margin-bottom: 20rpx;
	}

	.save-btn {
		width: 250rpx;
		height: 70rpx;
		line-height: 70rpx;
		background-color: #0AA344;
		color: #FFFFFF;
		font-size: 26rpx;
		border-radius: 8rpx;
	}
</style>
