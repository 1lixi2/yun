<template>
	<view class="profile-container">
		<!-- 用户头像部分 -->
		<view class="user-header">
			<view class="avatar-container">
				<image class="avatar" src="/static/tou.png" mode="aspectFill"></image>
				<view class="avatar-border"></view>
			</view>
			<view class="username-container">
				<text class="username">林业防虫大队</text>
				<image class="blue-icon" src="/static/blue.png" mode="aspectFit"></image>
			</view>
			<text class="user-bio">专注林业害虫防治，守护绿色家园</text>
		</view>

		<!-- 用户数据统计 -->
		<view class="stats-container">
			<view class="stat-item">
				<text class="stat-number">128</text>
				<text class="stat-label">识别记录</text>
			</view>
			<view class="stat-divider"></view>
			<view class="stat-item">
				<text class="stat-number">56</text>
				<text class="stat-label">收藏图鉴</text>
			</view>
			<view class="stat-divider"></view>
			<view class="stat-item">
				<text class="stat-number">32</text>
				<text class="stat-label">防治方案</text>
			</view>
		</view>

		<!-- 功能区块 -->
		<view class="features-container">
			<view class="feature-item">
				<view class="feature-icon">📋</view>
				<text class="feature-text">我的记录</text>
			</view>
			<view class="feature-item">
				<view class="feature-icon">⭐</view>
				<text class="feature-text">我的收藏</text>
			</view>
			<view class="feature-item">
				<view class="feature-icon">🔔</view>
				<text class="feature-text">消息通知</text>
			</view>
			<view class="feature-item">
				<view class="feature-icon">⚙️</view>
				<text class="feature-text">设置</text>
			</view>
		</view>

		<!-- 昆虫图片展示部分 -->
		<view class="insect-gallery">
			<view class="section-header">
				<text class="section-title">昆虫图片集</text>
				<text class="section-more">查看全部</text>
			</view>
			<view class="insect-grid">
				<view class="insect-item" v-for="(img, index) in insectImages" :key="index" @click="previewImage(index)">
					<image class="insect-image" :src="img" mode="aspectFill"></image>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				insectImages: [
					'/static/iamges/15642.png',
					'/static/iamges/15635.jpg',
					'/static/iamges/15636.jpg',
					'/static/iamges/15637.jpg',
					'/static/iamges/15638.jpg',
					'/static/iamges/15639.jpg',
          '/static/iamges/15643.png',
          '/static/iamges/15644.png',
				]
			}
		},
		methods: {
			previewImage(index) {
				// 使用uni-app的预览图片API
				uni.previewImage({
					current: index,
					urls: this.insectImages,
					indicator: 'number',
					loop: true
				});
			}
		}
	}
</script>

<style>
	.profile-container {
		padding: 30rpx;
		display: flex;
		flex-direction: column;
		align-items: center;
		background-color: #C0EBD7;
		min-height: 100vh;
	}

	/* 用户头像和用户名样式 */
	.user-header {
		display: flex;
		flex-direction: column;
		align-items: center;
		margin-bottom: 40rpx;
		width: 100%;
		padding: 40rpx 0;
	}

	.avatar-container {
		position: relative;
		margin-bottom: 30rpx;
	}

	.avatar {
		width: 180rpx;
		height: 180rpx;
		border-radius: 90rpx; /* 圆形头像 */
		border: 6rpx solid #ffffff;
		box-shadow: 0 4rpx 20rpx rgba(0, 0, 0, 0.15);
		z-index: 2;
		position: relative;
	}

	.avatar-border {
		position: absolute;
		width: 200rpx;
		height: 200rpx;
		border-radius: 100rpx;
		border: 4rpx dashed #0AA344;
		top: -10rpx;
		left: -10rpx;
		animation: rotate 20s linear infinite;
	}

	@keyframes rotate {
		from { transform: rotate(0deg); }
		to { transform: rotate(360deg); }
	}

	.username-container {
		display: flex;
		align-items: center;
		justify-content: center;
		margin-bottom: 15rpx;
	}

	.username {
		font-size: 40rpx;
		font-weight: bold;
		color: #0AA344;
		margin-right: 16rpx;
	}

	.blue-icon {
		width: 40rpx;
		height: 40rpx;
	}

	.user-bio {
		font-size: 28rpx;
		color: #666;
		text-align: center;
		margin-top: 10rpx;
	}

	/* 用户数据统计 */
	.stats-container {
		display: flex;
		justify-content: space-around;
		align-items: center;
		width: 100%;
		background-color: #FFFFFF;
		border-radius: 20rpx;
		padding: 30rpx 0;
		margin-bottom: 40rpx;
		box-shadow: 0 4rpx 15rpx rgba(0, 0, 0, 0.08);
	}

	.stat-item {
		display: flex;
		flex-direction: column;
		align-items: center;
		flex: 1;
	}

	.stat-number {
		font-size: 36rpx;
		font-weight: bold;
		color: #0AA344;
		margin-bottom: 10rpx;
	}

	.stat-label {
		font-size: 24rpx;
		color: #666;
	}

	.stat-divider {
		width: 2rpx;
		height: 60rpx;
		background-color: #e0e0e0;
	}

	/* 功能区块 */
	.features-container {
		display: flex;
		justify-content: space-between;
		flex-wrap: wrap;
		width: 100%;
		margin-bottom: 40rpx;
	}

	.feature-item {
		width: 100%;
		background-color: #FFFFFF;
		border-radius: 20rpx;
		padding: 30rpx 20rpx;
		display: flex;
		align-items: center;
		margin-bottom: 20rpx;
		box-shadow: 0 4rpx 15rpx rgba(0, 0, 0, 0.08);
	}

	.feature-icon {
		font-size: 40rpx;
		margin-right: 20rpx;
	}

	.feature-text {
		font-size: 28rpx;
		color: #333;
		font-weight: 500;
	}

	/* 昆虫图片展示样式 */
	.insect-gallery {
		width: 100%;
		background-color: #FFFFFF;
		border-radius: 20rpx;
		padding: 30rpx;
		box-shadow: 0 4rpx 15rpx rgba(0, 0, 0, 0.08);
	}

	.section-header {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-bottom: 30rpx;
	}

	.section-title {
		font-size: 32rpx;
		font-weight: bold;
		color: #0AA344;
	}

	.section-more {
		font-size: 24rpx;
		color: #0AA344;
	}

	.insect-grid {
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		width: 100%;
	}

	.insect-item {
		width: 48%;
		margin-bottom: 20rpx;
		border-radius: 15rpx;
		overflow: hidden;
		box-shadow: 0 4rpx 10rpx rgba(0, 0, 0, 0.1);
		background-color: #f9f9f9;
	}

	.insect-image {
		width: 100%;
		height: 300rpx; /* 设置图片高度 */
	}
</style>
