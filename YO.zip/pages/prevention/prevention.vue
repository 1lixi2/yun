<template>
	<view class="prevention-container">
		<ai-chat />
		<view class="header">
			<text class="title">林业防虫指南</text>
		</view>

		<view class="content">
			<view class="section">
				<view class="section-title">防虫基本知识</view>
				<view class="section-content">
					<view class="info-item">
						<text class="info-title">什么是林业有害生物？</text>
						<text class="info-content">林业有害生物是指对森林、林木及其产品造成危害的生物，主要包括林业害虫、病原微生物和有害植物等。</text>
					</view>
					<view class="info-item">
						<text class="info-title">林业有害生物的危害</text>
						<text class="info-content">林业有害生物可导致林木生长受阻、死亡，降低森林质量，破坏生态系统平衡，造成巨大的经济损失和生态损害。</text>
					</view>
				</view>
			</view>

			<view class="section">
				<view class="section-title">常见防治方法</view>
				<view class="section-content">
					<view class="method-item">
						<text class="method-name">1. 生物防治</text>
						<text class="method-desc">利用天敌、拮抗微生物等自然因子控制害虫种群，如释放赤眼蜂防治松毛虫。</text>
					</view>
					<view class="method-item">
						<text class="method-name">2. 化学防治</text>
						<text class="method-desc">合理使用农药控制害虫，注意选择高效、低毒、低残留的药剂，避免环境污染。</text>
					</view>
					<view class="method-
item">
						<text class="method-name">3. 物理机械防治</text>
						<text class="method-desc">利用灯光诱杀、粘虫板、人工捕杀等方法减少害虫数量。</text>
					</view>
					<view class="method-item">
						<text class="method-name">4. 营林措施</text>
						<text class="method-desc">通过合理的造林、抚育、间伐等措施，提高林木抗性，减少病虫害发生。</text>
					</view>
					<view class="method-item">
						<text class="method-name">5. 综合防治</text>
						<text class="method-desc">结合多种防治方法，根据害虫发生规律和特点，制定科学的防治策略。</text>
					</view>
				</view>
			</view>

			<view class="section">
				<view class="section-title">季节性防虫提示</view>
				<view class="section-content">
					<view class="season-item">
						<text class="season-name">春季</text>
						<text class="season-tips">重点监测越冬害虫的复苏情况，及时清理病枝、虫巢，做好早期防治工作。</text>
					</view>
					<view class="season-item">
						<text class="season-name">夏季</text>
						<text class="season-tips">害虫繁殖速度快，种群数量大，是防治的关键时期，要加强监测和防治力度。</text>
					</view>
					<view class="season-item">
						<text class="season-name">秋季</text>
						<text class="season-tips">注意防治害虫的越冬准备，清除落叶等越冬场所，减少越冬虫源。</text>
					</view>
					<view class="season-item">
						<text class="season-name">冬季</text>
						<text class="season-tips">利用害虫越冬期，清理林内杂物，消灭越冬虫源，为来年减轻虫害做准备。</text>
					</view>
          <view class="season-item">
						<text class="season-name">了解更多</text>
						<text class="season-tips">想了解更多？，访问我们的AI智能助手或加载更多知识</text>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import AiChat from '@/components/AiChat/AiChat.vue';

	export default {
		components: {
			AiChat
		},
		data() {
			return {

			}
		},
		methods: {

		}

	}
</script>

<style lang="scss">
.prevention-container {
	padding: 30rpx;
	background-color: #C0EBD7;
	min-height: 100vh;

	.header {
		padding: 40rpx 0;
		text-align: center;

		.title {
			font-size: 44rpx;
			font-weight: bold;
			color: #0AA344;
			position: relative;
			display: inline-block;

			&:after {
				content: '';
				position: absolute;
				bottom: -10rpx;
				left: 50%;
				transform: translateX(-50%);
				width: 100rpx;
				height: 6rpx;
				background-color: #F0F0F4;
				border-radius: 3rpx;
			}
		}
	}

	.content {
		.section {
			margin-bottom: 50rpx;
			background-color: #F0F0F4;
			border-radius: 20rpx;
			box-shadow: 0 4rpx 15rpx rgba(0, 0, 0, 0.08);
			overflow: hidden;
			border: 1rpx solid rgba(255,255,255,0.5);

			.section-title {
				padding: 25rpx 30rpx;
				font-size: 34rpx;
				font-weight: bold;
				background-color: #0AA344;
				color: #ffffff;
				position: relative;

				&:before {
					content: '';
					position: absolute;
					left: 20rpx;
					top: 50%;
					transform: translateY(-50%);
					width: 8rpx;
					height: 30rpx;
					background-color: #ffffff;
					border-radius: 4rpx;
				}
			}

			.section-content {
				padding: 30rpx;

				.info-item, .method-item, .season-item {
					margin-bottom: 30rpx;
					padding-bottom: 30rpx;
					border-bottom: 1rpx solid rgba(0,0,0,0.05);
					position: relative;
					padding-left: 40rpx;

					&:last-child {
						margin-bottom: 0;
						padding-bottom: 0;
						border-bottom: none;
					}

					&:before {
						content: '•';
						position: absolute;
						left: 15rpx;
						top: 0;
						color: #0AA344;
						font-size: 36rpx;
					}
				}

				.info-title, .method-name, .season-name {
					display: block;
					font-size: 30rpx;
					font-weight: bold;
					color: #333333;
					margin-bottom: 15rpx;
				}

				.info-content, .method-desc, .season-tips {
					display: block;
					font-size: 28rpx;
					color: #555555;
					line-height: 1.8;
				}

				.method-name {
					color: #0AA344;
				}

				.season-name {
					color: #FF6B81;
				}
			}
		}
	}
}
</style>
