<template>
	<view class="container">
		<view class="content">
			<image class="logo" src="/static/logo.png" mode="aspectFit"></image>
			<view class="title">林业害虫识别系统</view>
			<view class="subtitle">欢迎回来</view>
		</view>
	</view>
</template>

<script>
	// 确保页面正确注册
	export default {
		data() {
			return {

			}
		},
		onLoad() {
			console.log('欢迎页面加载成功');
			// 1.5秒后自动跳转到识别页面
			setTimeout(() => {
				console.log('准备跳转到识别页面');
				uni.switchTab({
					url: '/pages/identify/identify',
					success: function() {
						console.log('跳转成功');
					},
					fail: function(err) {
						console.error('跳转失败:', err);
						// 尝试使用reLaunch方法
						uni.reLaunch({
							url: '/pages/identify/identify',
							success: function() {
								console.log('reLaunch跳转成功');
							},
							fail: function(err) {
								console.error('reLaunch跳转失败:', err);
								// 最后尝试navigateTo
								uni.navigateTo({
									url: '../identify/identify',
									success: function() {
										console.log('navigateTo跳转成功');
									},
									fail: function(err) {
										console.error('navigateTo跳转失败:', err);
									}
								});
							}
						});
					}
				});
			}, 1500);
		},
		onShow() {
			console.log('welcome页面显示');
		}
	}
</script>

<style>
	.container {
		height: 100vh;
		width: 100%;
		display: flex;
		justify-content: center;
		align-items: center;
		background: linear-gradient(135deg, #C0EBD7 0%, #F0F0F4 100%);
	}

	.content {
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
		justify-content: flex-start;
		align-items: center;
		padding-top: 120px;
	}

	.logo {
		width: 200px;
		height: 200px;
		margin-bottom: 50px;
		animation: fadeInDown 0.8s ease-out;
	}

	.title {
		font-size: 36px;
		font-weight: bold;
		color: #0AA344;
		margin-bottom: 20px;
		text-align: center;
		text-shadow: 0 2px 4px rgba(0,0,0,0.1);
		animation: fadeIn 1s ease-out 0.3s both;
	}

	.subtitle {
		font-size: 24px;
		color: #555;
		text-align: center;
		animation: fadeIn 1s ease-out 0.6s both;
	}

	@keyframes fadeIn {
		from { opacity: 0; transform: translateY(10px); }
		to { opacity: 1; transform: translateY(0); }
	}

	@keyframes fadeInDown {
		from { opacity: 0; transform: translateY(-20px); }
		to { opacity: 1; transform: translateY(0); }
	}
</style>
