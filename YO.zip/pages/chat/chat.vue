<template>
	<view class="chat-page">
		<!-- 聊天框 -->
		<view class="chat-box">
			<view class="chat-header">
				<text class="chat-title">林业害虫智能助手</text>
				<text class="close-btn" @click="goBack">×</text>
			</view>

			<scroll-view class="chat-messages" scroll-y="true" :scroll-top="scrollTop" @scrolltoupper="loadMoreMessages"
			:style="{height: scrollViewHeight + 'px'}">
				<view class="message-list">
					<view v-for="(msg, index) in messages" :key="index" class="message" :class="msg.type">
						<view class="message-content">
							<view v-if="msg.type === 'ai'" class="ai-avatar">
								<image src="/static/robot.png" mode="aspectFit"></image>
							</view>
							<view v-if="msg.type === 'user'" class="user-avatar">
								<image src="/static/lang.png" mode="aspectFit"></image>
							</view>
							<view class="message-bubble">
								<text>{{ msg.content }}</text>
							</view>
						</view>
						<text class="message-time">{{ msg.time }}</text>
					</view>
				</view>
				<view class="loading" v-if="isLoading">
					<text>正在思考...</text>
				</view>
			</scroll-view>

			<view class="chat-input">
				<input
					type="text"
					v-model="inputMessage"
					placeholder="请输入您的问题..."
					confirm-type="send"
					@confirm="sendMessage"
				/>
				<button @click="sendMessage" :disabled="!inputMessage.trim() || isLoading">发送</button>
			</view>
		</view>
	</view>
</template>

<script>
	import { deepseekConfig } from '@/config/api.js';

	export default {
		name: 'ChatPage',
		data() {
			return {
				inputMessage: '',
				messages: [
					{
						type: 'ai',
						content: '您好！我是林业害虫智能助手，请问有什么可以帮助您的？',
						time: this.formatTime(new Date())
					}
				],
				isLoading: false,
				scrollTop: 0,
				scrollViewHeight: 500, // 初始高度
				apiConfig: deepseekConfig,
				currentRequestTask: null // 用于存储当前请求任务
			}
		},

		onLoad() {
			// 计算scroll-view高度
			const systemInfo = uni.getSystemInfoSync();
			const query = uni.createSelectorQuery().in(this);
			query.select('.chat-header').boundingClientRect();
			query.select('.chat-input').boundingClientRect();
			query.exec(res => {
				if (res[0] && res[1]) {
					this.scrollViewHeight = systemInfo.windowHeight - res[0].height - res[1].height;
				}
			});
		},
		methods: {
			goBack() {
				uni.navigateBack();
			},

			// 发送消息
			async sendMessage() {
				if (!this.inputMessage.trim() || this.isLoading) return;

				// 添加用户消息
				const userMessage = {
					type: 'user',
					content: this.inputMessage,
					time: this.formatTime(new Date())
				};
				this.messages.push(userMessage);

				// 清空输入框
				const userInput = this.inputMessage;
				this.inputMessage = '';

				// 滚动到底部
				this.$nextTick(() => {
					this.scrollToBottom();
				});

				// 显示加载状态
				this.isLoading = true;

				// 创建AI消息占位
				const aiMessage = {
					type: 'ai',
					content: '正在思考...',
					time: this.formatTime(new Date()),
					isStreaming: true
				};
				this.messages.push(aiMessage);
				const aiMessageIndex = this.messages.length - 1;

				try {
					// 调用DeepSeek API
					const response = await this.callDeepSeekAPI(userInput);

					// 更新AI消息内容
					this.$set(this.messages, aiMessageIndex, {
						...aiMessage,
						content: this.formatResponseText(response),
						isStreaming: false
					});

					this.scrollToBottom();
				} catch (error) {
					console.error('发送消息失败:', error);
					this.$set(this.messages, aiMessageIndex, {
						...aiMessage,
						content: '请求失败: ' + (error.message || '未知错误'),
						isStreaming: false
					});
				} finally {
					this.isLoading = false;
					this.currentRequestTask = null;
				}
			},

			// 调用DeepSeek API (非流式版本)
			callDeepSeekAPI(userInput) {
				// 确保始终返回Promise
				try {
					// 检查API配置
					if (!this.apiConfig.apiUrl || !this.apiConfig.apiKey) {
						throw new Error('请先在设置中配置API URL和API Key');
					}

					// 构建请求体
					const requestBody = {
						model: this.apiConfig.model,
						messages: [
							{
								role: "system",
								content: this.apiConfig.systemPrompt
							},
							{
								role: "user",
								content: userInput
							}
						],
						temperature: this.apiConfig.temperature,
						max_tokens: this.apiConfig.maxTokens,
						stream: false // 禁用流式响应
					};

					// 返回Promise
					return new Promise((resolve, reject) => {
						this.currentRequestTask = uni.request({
							url: this.apiConfig.apiUrl,
							method: 'POST',
							header: {
								'Content-Type': 'application/json',
								'Authorization': `Bearer ${this.apiConfig.apiKey}`
							},
							data: requestBody,
							success: (res) => {
								try {
									if (res.statusCode !== 200) {
										throw new Error(`API请求失败: ${res.statusCode}`);
									}

									if (!res.data || !res.data.choices || !res.data.choices[0].message) {
										throw new Error('API返回数据格式不正确');
									}

									resolve(res.data.choices[0].message.content);
								} catch (error) {
									reject(error);
								}
							},
							fail: (err) => {
								reject(new Error(`请求失败: ${err.errMsg || '未知错误'}`));
							},
							complete: () => {
								this.currentRequestTask = null;
							}
						});
					});
				} catch (error) {
					// 同步错误也返回rejected Promise
					console.error('API调用初始化失败:', error);
					return Promise.reject(error);
				}
			},

			// 取消当前请求
			cancelRequest() {
				if (this.currentRequestTask) {
					// 如果是WebSocket连接
					if (this.currentRequestTask.close) {
						this.currentRequestTask.close({
							success: () => console.log('WebSocket已关闭'),
							fail: (err) => console.error('关闭WebSocket失败:', err)
						});
					}
					// 如果是普通请求
					else if (this.currentRequestTask.abort) {
						this.currentRequestTask.abort();
					}

					this.currentRequestTask = null;
					this.isLoading = false;
				}
			},

			// 添加取消按钮功能
			addCancelButton() {
				if (this.isLoading && this.currentRequestTask) {
					// 在最后一条消息下方添加取消按钮
					const lastMessageIndex = this.messages.length - 1;
					if (this.messages[lastMessageIndex] && this.messages[lastMessageIndex].isStreaming) {
						// 添加取消按钮逻辑
						console.log('可以添加取消按钮');
					}
				}
			},

			// 格式化时间
			formatTime(date) {
				const hours = date.getHours().toString().padStart(2, '0');
				const minutes = date.getMinutes().toString().padStart(2, '0');
				return `${hours}:${minutes}`;
			},

			// 滚动到底部
			scrollToBottom() {
				// 使用nextTick确保DOM已更新
				this.$nextTick(() => {
					const query = uni.createSelectorQuery().in(this);
					query.select('.chat-messages').boundingClientRect();
					query.select('.message-list').boundingClientRect();
					query.exec(res => {
						if (res[0] && res[1]) {
							// 增加额外的滚动距离确保消息可见
							const scrollDistance = res[1].height - res[0].height + 100;
							this.scrollTop = scrollDistance;

							// 添加延迟滚动确保DOM完全更新
							setTimeout(() => {
								this.scrollTop = scrollDistance + 1; // 微小变化确保滚动触发
							}, 100);
						}
					}).catch(err => {
						console.error('滚动计算失败:', err);
						// 回退到简单滚动方式
						this.scrollTop = 999999;
					});
				});
			},

			// 格式化API返回的文本
			formatResponseText(text) {
				// 移除所有Markdown符号
				return text
					.replace(/^#+\s*/gm, '')  // 移除标题符号
					.replace(/\*\*(.*?)\*\*/g, '$1')  // 移除加粗
					.replace(/\*(.*?)\*/g, '$1')  // 移除斜体
					.replace(/_/g, '')  // 移除下划线
					.replace(/```[\s\S]*?```/g, '')  // 移除代码块
					.replace(/`([^`]+)`/g, '$1')  // 移除行内代码
					.replace(/^-\s*/gm, '')  // 移除无序列表
					.replace(/^\d+\.\s*/gm, '')  // 移除有序列表
					.replace(/\[([^\]]+)\]\([^\)]+\)/g, '$1')  // 移除链接
					.replace(/!\[([^\]]+)\]\([^\)]+\)/g, '$1')  // 移除图片
					.replace(/\n{3,}/g, '\n\n')  // 合并多余空行
					.trim();  // 移除首尾空格
			},

			// 加载更多消息（上拉加载）
			loadMoreMessages() {
				// 这里可以实现加载历史消息的逻辑
				console.log('加载更多消息');
			}
		}
	}
</script>

<style lang="scss" scoped>
.chat-page {
	width: 100%;
	height: 100vh;
	background-color: #f5f5f5;

	.chat-box {
		width: 100%;
		height: 100%;
		background-color: #ffffff;
		display: flex;
		flex-direction: column;
		overflow: hidden;

		.chat-header {
			height: 80rpx;
			background-color: #4CAF50;
			color: #ffffff;
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 0 20rpx;

			.chat-title {
				font-size: 32rpx;
				font-weight: bold;
			}

			.close-btn {
				font-size: 48rpx;
				line-height: 1;
				padding: 0 10rpx;
			}
		}

		.chat-messages {
			flex: 1;
			padding: 20rpx;
			background-color: #f5f5f5;

			.message-list {
				display: flex;
				flex-direction: column;

				.message {
					margin-bottom: 20rpx;
					max-width: 80%;

					.message-content {
						display: flex;
						align-items: flex-start;
					}

					.ai-avatar {
						width: 70rpx;
						height: 70rpx;
						margin-right: 10rpx;
						border-radius: 50%;
						overflow: hidden;
						box-shadow: 0 0 5rpx rgba(144, 147, 153, 0.5); // 添加灰色阴影效果
						border: 2rpx solid #909399; // 添加灰色边框，与AI消息气泡颜色一致

						image {
							width: 100%;
							height: 100%;
							border-radius: 50%;
						}
					}

					.user-avatar {
						width: 70rpx;
						height: 70rpx;
						margin-right: 0;
						margin-left: 10rpx;
						border-radius: 50%;
						overflow: hidden;
						border: 2rpx solid #007AFF; // 添加蓝色边框，与用户消息气泡颜色一致
						box-shadow: 0 0 5rpx rgba(0, 122, 255, 0.5); // 添加蓝色阴影效果

						image {
							width: 100%;
							height: 100%;
							border-radius: 50%;
						}
					}

					.user-avatar {
						margin-right: 0;
						margin-left: 10rpx;
						border: 2rpx solid #057748 !important; // 添加蓝色边框，与用户消息气泡颜色一致，使用!important覆盖默认边框
						box-shadow: 0 0 5rpx rgba(0, 122, 255, 0.5) !important; // 添加蓝色阴影效果，使用!important覆盖默认阴影
					}

					.message-bubble {
						padding: 16rpx 20rpx;
						border-radius: 18rpx;
						font-size: 28rpx;
						line-height: 1.4;
						word-break: break-word;
					}

					.message-time {
						font-size: 24rpx;
						color: #999;
						margin-top: 6rpx;
						margin-left: 70rpx;
					}

					&.user {
						align-self: flex-end;
						margin-right: 20rpx; // 增加右侧边距

						.message-content {
							flex-direction: row-reverse;
						}

						.message-bubble {
							background-color: #007AFF;
							color: #ffffff;
							border-top-right-radius: 4rpx;
							margin-right: 10rpx; // 增加消息气泡与头像的间距
						}

						.message-time {
							text-align: right;
							margin-right: 80rpx; // 增加时间戳右侧边距，与更大的头像对齐
							margin-left: 0;
						}
					}

					&.ai {
						align-self: flex-start;

						.message-bubble {
							background-color: #ffffff;
							border-top-left-radius: 4rpx;
						}
					}
				}
			}

			.loading {
				text-align: center;
				padding: 10rpx 0;
				font-size: 24rpx;
				color: #999;
			}
		}

		.chat-input {
			height: 100rpx;
			display: flex;
			align-items: center;
			padding: 0 20rpx;
			border-top: 2rpx solid #eee;

			input {
				flex: 1;
				height: 70rpx;
				background-color: #f5f5f5;
				border-radius: 35rpx;
				padding: 0 30rpx;
				font-size: 28rpx;
			}

			button {
				width: 120rpx;
				height: 70rpx;
				background-color: #4CAF50;
				color: #ffffff;
				border-radius: 35rpx;
				margin-left: 20rpx;
				font-size: 28rpx;
				display: flex;
				justify-content: center;
				align-items: center;
				padding: 0;

				&:disabled {
					background-color: #cccccc;
				}
			}
		}
	}
}
</style>
