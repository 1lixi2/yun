<template>
	<view class="container">
		<ai-chat />
		<view class="title">林业害虫识别</view>

		<!-- 上传区域 -->
		<view class="upload-area" @click="uploadImage">
			<image v-if="!selectedImage" class="upload-icon" src="/static/picture.png"></image>
			<image v-else class="preview-image" :src="selectedImage"></image>
			<text v-if="!selectedImage" class="upload-text">点击上传图片</text>
		</view>

		<!-- 识别按钮 -->
		<button class="identify-btn" @click="showModelPicker">开始识别</button>

		<!-- 模型选择弹窗 -->
		<uni-popup ref="modelPopup" type="dialog">
			<uni-popup-dialog
				mode="base"
				title="选择模型"
				content="请选择要使用的识别模型"
				:before-close="true"
				@confirm="confirmModel"
				@close="closeModelPopup"
				:show-cancel="true"
				cancel-text="取消"
			>
				<radio-group @change="handleModelChange">
					<label class="model-option">
						<radio value="v5" checked /> V5模型(基础版)
					</label>
					<label class="model-option">
						<radio value="v12" /> V12模型(增强版)
					</label>
				</radio-group>
			</uni-popup-dialog>
		</uni-popup>

		<!-- 历史记录 -->
		<view class="history-section" v-if="historyImages.length > 0">
			<text class="history-title">上次搜索</text>
			<view class="history-images">
				<image
					v-for="(img, index) in displayHistoryImages"
					:key="index"
					:src="img"
					class="history-image"
					@click="showImageOptions(img, index)"
				></image>
			</view>
		</view>

		<!-- 图片操作菜单 -->
		<uni-popup ref="imageOptionsPopup" type="bottom">
			<view class="image-options">
				<view class="option-item" @click="downloadImage">
					<text class="option-text">下载图片</text>
				</view>
				<view class="option-item" @click="deleteImage">
					<text class="option-text">删除图片</text>
				</view>
				<view class="option-item cancel" @click="closeImageOptions">
					<text class="option-text">取消</text>
				</view>
			</view>
		</uni-popup>

		<!-- 识别结果弹窗 -->
		<uni-popup ref="popup" type="center">
			<view class="popup-content" v-if="result">
				<text class="result-title">识别结果</text>
				<view class="result-item">
					<text class="label">害虫名称:</text>
					<text class="value">{{result.name}}</text>
				</view>
				<view class="result-item">
					<text class="label">英文名称:</text>
					<text class="value">{{result.englishName}}</text>
				</view>
				<view class="result-item">
					<text class="label">置信度:</text>
					<text class="value">{{result.confidence}}</text>
				</view>
				<view class="result-item">
					<text class="label">检测数量:</text>
					<text class="value">{{result.count}}</text>
				</view>
				<button class="close-btn" @click="closePopup">关闭</button>
			</view>
		</uni-popup>
	</view>
</template>

<script>
	import AiChat from '@/components/AiChat/AiChat.vue'

	export default {
		components: {
			AiChat
		},
		onShow() {
			// 确保从其他页面返回时，模型选择弹窗是关闭状态
			if (this.$refs.modelPopup) {
				this.$refs.modelPopup.close();
			}
		},
		onLoad() {
			// 加载历史记录
			this.loadHistoryFromStorage();
		},
		data() {
			return {
				selectedImage: '', // 当前选择的图片
				historyImages: [], // 历史图片
				currentHistoryImage: '', // 当前选中的历史图片
				currentHistoryIndex: -1, // 当前选中的历史图片索引
				loading: false, // 加载状态
				result: null, // 识别结果
				showResult: false, // 是否显示结果
				currentModel: 'v5', // 当前选择的模型
				showModelDialog: false // 是否显示模型选择对话框
			}
		},
		computed: {
			// 只显示最近的3张历史图片
			displayHistoryImages() {
				return this.historyImages.slice(-3);
			}
		},
		methods: {
			// 上传图片方法
			uploadImage() {
				// 显示选择菜单
				uni.showActionSheet({
					itemList: ['从图库中选择', '直接拍照'],
					success: (res) => {
						if (res.tapIndex === 0) {
							// 从图库中选择
							this.chooseFromAlbum();
						} else if (res.tapIndex === 1) {
							// 直接拍照
							this.takePhoto();
						}
					},
					fail: (err) => {
						console.error('操作取消:', err);
					}
				});
			},

			// 从图库中选择图片
			chooseFromAlbum() {
				uni.chooseImage({
					count: 1, // 最多可以选择的图片张数
					sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图
					sourceType: ['album'], // 只从相册选择
					success: (res) => {
						this.selectedImage = res.tempFilePaths[0];
						console.log('从图库选择图片成功:', this.selectedImage);

						// 将新图片添加到历史记录
						this.addToHistory(this.selectedImage);
					},
					fail: (err) => {
						console.error('选择图片失败:', err);
						uni.showToast({
							title: '选择图片失败',
							icon: 'none'
						});
					}
				});
			},

			// 直接拍照
			takePhoto() {
				uni.chooseImage({
					count: 1, // 只拍一张照片
					sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图
					sourceType: ['camera'], // 只使用相机
					success: (res) => {
						this.selectedImage = res.tempFilePaths[0];
						console.log('拍照成功:', this.selectedImage);

						// 将新图片添加到历史记录
						this.addToHistory(this.selectedImage);
					},
					fail: (err) => {
						console.error('拍照失败:', err);
						uni.showToast({
							title: '拍照失败',
							icon: 'none'
						});
					}
				});
			},

			// 添加图片到历史记录
			addToHistory(imagePath) {
				// 检查图片是否已存在于历史记录中
				if (!this.historyImages.includes(imagePath)) {
					this.historyImages.push(imagePath);
				}

				// 保存历史记录到本地存储
				this.saveHistoryToStorage();
			},

			// 保存历史记录到本地存储
			saveHistoryToStorage() {
				try {
					uni.setStorageSync('historyImages', JSON.stringify(this.historyImages));
				} catch (e) {
					console.error('保存历史记录失败:', e);
				}
			},

			// 从本地存储加载历史记录
			loadHistoryFromStorage() {
				try {
					const history = uni.getStorageSync('historyImages');
					if (history) {
						this.historyImages = JSON.parse(history);
					}
				} catch (e) {
					console.error('加载历史记录失败:', e);
				}
			},

			// 显示图片操作菜单
			showImageOptions(img, index) {
				this.currentHistoryImage = img;
				this.currentHistoryIndex = index;
				this.$refs.imageOptionsPopup.open();
			},

			// 下载图片
			downloadImage() {
				if (!this.currentHistoryImage) return;

				uni.saveImageToPhotosAlbum({
					filePath: this.currentHistoryImage,
					success: () => {
						uni.showToast({
							title: '图片已保存到相册',
							icon: 'success'
						});
						this.closeImageOptions();
					},
					fail: (err) => {
						console.error('保存图片失败:', err);
						uni.showToast({
							title: '保存图片失败',
							icon: 'none'
						});
					}
				});
			},

			// 删除图片
			deleteImage() {
				if (this.currentHistoryIndex === -1) return;

				// 从历史记录中删除图片
				const index = this.historyImages.indexOf(this.currentHistoryImage);
				if (index !== -1) {
					this.historyImages.splice(index, 1);
					this.saveHistoryToStorage();
				}

				this.closeImageOptions();

				uni.showToast({
					title: '图片已删除',
					icon: 'success'
				});
			},

			// 关闭图片操作菜单
			closeImageOptions() {
				this.$refs.imageOptionsPopup.close();
				this.currentHistoryImage = '';
				this.currentHistoryIndex = -1;
			},

			// 开始识别方法
			// 关闭结果弹窗
			closePopup() {
				this.$refs.popup.close();
			},

			// 显示模型选择弹窗
			showModelPicker() {
				this.$refs.modelPopup.open();
			},

			// 处理模型选择变化
			handleModelChange(e) {
				this.currentModel = e.detail.value;
			},

			// 确认模型选择
			confirmModel() {
				this.startIdentify();
				this.$refs.modelPopup.close();
			},

			// 关闭模型选择弹窗
			closeModelPopup() {
				this.$refs.modelPopup.close();
			},

      async startIdentify() {
        if (!this.selectedImage) {
          uni.showToast({
            title: '请先上传图片',
            icon: 'none'
          });
          return;
        }

        this.loading = true;
        uni.showLoading({
          title: '上传中...',
          mask: true
        });

        try {
          console.log('准备上传文件:', {
            filePath: this.selectedImage,
            fileInfo: this.selectedImage ? '文件已选择' : '未选择文件',
            fileSize: this.selectedImage ? '需要获取文件大小' : '无文件'
          });

          // 根据选择的模型使用不同的API
          const apiUrl = this.currentModel === 'v5'
              ? 'http://192.168.234.25:5000/api/detect/5'
              : 'http://192.168.234.25:5000/api/detect/12';

          const res = await uni.uploadFile({
            url: apiUrl,
            filePath: this.selectedImage,
            name: 'image',
            header: {
              'Content-Type': 'multipart/form-data'
            }
          });

          console.log('上传响应:', {
            statusCode: res.statusCode,
            data: res.data,
            headers: res.header,
            errMsg: res.errMsg
          });

          // 检查HTTP状态码
          if (res.statusCode !== 200) {
            console.error('上传失败详情:', res);
            throw new Error(`上传失败: ${res.statusCode} - ${res.errMsg}`);
          }

          // 解析响应数据 - uni.uploadFile返回的数据结构特殊
          console.log('原始响应数据:', res);
          let responseData;

          try {
            // uni.uploadFile的响应data可能是字符串或已解析对象
            responseData = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;
            console.log('解析后的数据:', responseData);

            // 检查响应结构
            if (!responseData || typeof responseData !== 'object') {
              throw new Error('无效的响应格式');
            }

            // 直接使用解析后的数据
            if (responseData.status !== 'success') {
              throw new Error(responseData.message || '识别失败: 未知错误');
            }

            // 处理API返回的检测结果
            console.log('API响应数据:', responseData);

            // 处理图片URL，直接在这里拼接完整路径
            let imageUrl = responseData.result_image_url || responseData.image_url; // 优先使用result_image_url

            // 如果是相对路径，转换为本地文件路径
            if (imageUrl && imageUrl.startsWith('/')) {
              // 使用本地文件路径，使用正斜杠格式
              imageUrl = 'D:/1/YOLO/yoloflask' + imageUrl;
              console.log('转换后的图片路径:', imageUrl);
            }

            // 处理V12和V5不同的数据格式
            let resultsArray = [];
            if (responseData.results) {
              // 检查results是否为数组（V5格式）或对象（V12格式）
              if (Array.isArray(responseData.results)) {
                // V5格式，直接使用数组
                resultsArray = responseData.results;
              } else if (typeof responseData.results === 'object') {
                // V12格式，将单个对象转换为数组
                resultsArray = [responseData.results];
              }
            }

            console.log('处理后的结果数组:', resultsArray);

            const resultData = {
              results: resultsArray,
              imageUrl: imageUrl,
              detectedCount: resultsArray.length
            };

            // 验证结果数据
            if (!resultData.results || !resultData.imageUrl) {
              console.error('无效的结果数据:', resultData);
              uni.showToast({
                title: '获取结果失败',
                icon: 'none'
              });
              return;
            }

            // 构造跳转URL
            const detailUrl = '/pages/identify/detail?data=' + encodeURIComponent(JSON.stringify(resultData));
            console.log('准备跳转到:', detailUrl);

            // 跳转到详情页面并传递数据
            uni.navigateTo({
              url: detailUrl,
              success: () => {
                console.log('跳转到详情页成功');
              },
              fail: (err) => {
                console.error('跳转失败:', err);
                // 跳转失败时显示弹窗作为备选方案
                this.result = resultData;
                this.$refs.popup.open();
                uni.showToast({
                  title: '跳转失败，已显示结果',
                  icon: 'none'
                });
              }
            });
          } catch (parseError) {
            console.error('解析响应详细错误:', {
              error: parseError,
              response: res.data,
              responseType: typeof res.data
            });
            throw new Error('解析响应失败: ' + parseError.message);
          }
        } catch (err) {
          console.error('上传错误:', err);
          uni.showToast({
            title: '上传失败: ' + (err.errMsg || '未知错误'),
            icon: 'none'
          });
        } finally {
          this.loading = false;
          uni.hideLoading();
        }
      }

    }
	}
</script>

<style>
	.container {
		display: flex;
		flex-direction: column;
		align-items: center;
		padding: 40rpx;
		box-sizing: border-box;
		min-height: 100vh;
		padding-bottom: 160rpx; /* 为按钮留出空间 */
	}

	.title {
		font-size: 24px;
		font-weight: bold;
		color: #0AA344;
		margin-bottom: 40rpx;
		margin-top: 20rpx;
	}

	/* 上传区域样式 */
	.upload-area {
		width: 400rpx;
		height: 400rpx;
		margin: 40rpx auto;
		border: 2rpx dashed #0AA344;
		border-radius: 20rpx;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		background-color: rgba(10, 163, 68, 0.05);
	}

	.upload-icon {
		width: 120rpx;
		height: 120rpx;
		margin-bottom: 20rpx;
	}

	.upload-text {
		color: #666;
		font-size: 14px;
		margin-top: 10rpx;
	}

	.preview-image {
		width: 380rpx;
		height: 380rpx;
		border-radius: 16rpx;
		object-fit: cover;
	}

	/* 识别按钮样式 */
	.identify-btn {
		margin-top: 40rpx;
		width: 80%;
		background-color: #0AA344;
		color: white;
		border-radius: 40rpx;
		font-size: 18px;
		padding: 6rpx 0;
	}

	/* 历史记录区域 */
	.history-section {
		margin-top: 60rpx;
		width: 100%;
	}

	.history-title {
		font-size: 18px;
		font-weight: bold;
		margin-bottom: 20rpx;
		display: block;
		color: #333;
	}

	.history-images {
		display: flex;
		justify-content: space-between;
		width: 100%;
	}

	.history-image {
		width: 220rpx;
		height: 220rpx;
		border-radius: 10rpx;
		object-fit: cover;
	}

	/* 识别结果弹窗样式 */
	.popup-content {
		background-color: #fff;
		padding: 40rpx;
		border-radius: 16rpx;
		width: 600rpx;
	}

	.result-title {
		font-size: 36rpx;
		font-weight: bold;
		margin-bottom: 30rpx;
		display: block;
		text-align: center;
		color: #333;
	}

	.result-item {
		display: flex;
		margin-bottom: 20rpx;
		align-items: center;
	}

	.result-item .label {
		font-weight: bold;
		width: 150rpx;
		color: #666;
	}

	.result-item .value {
		flex: 1;
		color: #333;
	}

	.close-btn {
		margin-top: 40rpx;
		background-color: #0AA344;
		color: white;
		width: 100%;
		border-radius: 40rpx;
		font-size: 16px;
		padding: 10rpx 0;
	}
</style>
