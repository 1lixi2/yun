<template>
	<view class="container">
		<ai-chat />
		<view class="title">识别详情</view>

		<!-- 结果图片 -->
		<view class="image-container">
			<image v-if="resultData.imageUrl" :src="resultData.imageUrl" class="result-image" mode="aspectFit"></image>
		</view>

		<!-- 多个检测结果 -->
		<view v-for="(result, index) in resultData.results" :key="index" class="info-card">
			<view class="info-header">
				<text class="info-title">检测结果 {{index + 1}}</text>
			</view>

			<view class="info-item">
				<text class="label">害虫名称:</text>
				<text class="value">{{result.chinese_name}}</text>
			</view>

			<view class="info-item">
				<text class="label">英文名称:</text>
				<text class="value">{{result.english_name}}</text>
			</view>

			<view class="info-item">
				<text class="label">置信度:</text>
				<text class="value">{{(result.confidence * 100).toFixed(1)}}%</text>
			</view>

			<view class="info-item">
				<text class="label">位置:</text>
				<text class="value">x:{{result.bbox[0].toFixed(0)}}, y:{{result.bbox[1].toFixed(0)}}</text>
			</view>
		</view>

		<view class="info-card">
			<view class="info-header">
				<text class="info-title">统计信息</text>
			</view>
			<view class="info-item">
				<text class="label">总检测数量:</text>
				<text class="value">{{resultData.detectedCount}}</text>
			</view>
		</view>

		<!-- 防治建议 -->
		<view class="info-card">
			<view class="info-header">
				<text class="info-title">防治建议</text>
			</view>

			<view class="suggestion-content">
				<view v-if="isLoadingSuggestions" class="loading-container">
					<text>正在获取防治建议...</text>
				</view>
				<view v-else>
					<view v-for="(suggestion, index) in preventionSuggestions" :key="index"
						:class="{'suggestion-item': true, 'suggestion-title': isSuggestionTitle(suggestion), 'suggestion-list-item': isSuggestionListItem(suggestion), 'suggestion-paragraph': !isSuggestionTitle(suggestion) && !isSuggestionListItem(suggestion)}">
						{{ suggestion }}
					</view>
				</view>
			</view>
		</view>

		<!-- 底部按钮 -->
		<view class="button-group">
			<button class="action-btn share-btn" @click="shareResult">分享结果</button>
			<button class="action-btn back-btn" @click="goBack">返回</button>
		</view>
	</view>
</template>

<script>
	import AiChat from '@/components/AiChat/AiChat.vue'
	import { deepseekConfig } from '@/config/api.js'

	export default {
		components: {
			AiChat
		},
		data() {
			return {
				resultData: {
					results: [],
					imageUrl: '',
					detectedCount: 0
				},
				preventionSuggestions: [
					"根据识别结果，建议采取以下防治措施：",
					"1. 加强田间管理，及时清除杂草",
					"2. 合理使用生物农药进行防治",
					"3. 定期检查作物生长情况",
					"4. 采用物理防治与化学防治相结合的方法"
				],
				isLoadingSuggestions: false
			}
		},
    onLoad(options) {
      // 从页面参数中获取传递的数据
      if (options.data) {
        try {
          this.resultData = JSON.parse(decodeURIComponent(options.data));
          console.log('接收到的数据:', this.resultData);

          // 确保results是数组格式
          if (this.resultData.results && !Array.isArray(this.resultData.results)) {
            console.log('将非数组results转换为数组格式');
            this.resultData.results = [this.resultData.results];
            // 更新检测数量
            this.resultData.detectedCount = 1;
          }

          console.log('处理后的results:', this.resultData.results);
          console.log('接收到的图片路径:', this.resultData.imageUrl);

          // 如果有图片路径，读取本地文件
          if (this.resultData.imageUrl) {
            this.readLocalImage(this.resultData.imageUrl);
          }

          // 获取防治建议
          if (this.resultData.results && this.resultData.results.length > 0) {
            this.getPreventionSuggestions();
          }
        } catch (e) {
          console.error('解析数据失败:', e);
          uni.showToast({
            title: '数据加载失败',
            icon: 'none'
          });
        }
      }
    },
		methods: {
			// 返回上一页
			goBack() {
				uni.navigateBack();
			},

			// 分享结果
			shareResult() {
				// 准备要传递的数据
				const shareData = {
					imageUrl: this.resultData.imageUrl,
					results: this.resultData.results,
					detectedCount: this.resultData.detectedCount,
					preventionSuggestions: this.preventionSuggestions
				};

				// 将数据转换为字符串并编码
				const encodedData = encodeURIComponent(JSON.stringify(shareData));

				// 跳转到分享页面并传递数据
				uni.navigateTo({
					url: `/pages/share/share?data=${encodedData}`,
					success: () => {
						console.log('跳转到分享页面成功');
					},
					fail: (err) => {
						console.error('跳转到分享页面失败:', err);
						uni.showToast({
							title: '跳转失败',
							icon: 'none'
						});
					}
				});
			},

			// 处理图片路径
			readLocalImage(filePath) {
				console.log('原始图片路径:', filePath);

				// 检查文件路径是否为网络URL
				if (filePath.startsWith('http://') || filePath.startsWith('https://')) {
					console.log('使用网络URL:', filePath);
					return; // 已经是网络URL，不需要处理
				}

				// 处理Windows路径（将反斜杠转换为正斜杠）
				let normalizedPath = filePath.replace(/\\/g, '/');
				console.log('标准化路径:', normalizedPath);

				// 构造HTTP URL
				// 假设Flask服务器运行在localhost:5000
				const baseUrl = 'http://localhost:5000';

				// 从路径中提取static部分
				if (normalizedPath.includes('/static/')) {
					const staticPath = normalizedPath.split('/static/')[1];
					const newUrl = `${baseUrl}/static/${staticPath}`;
					console.log('转换为网络URL:', newUrl);
					this.resultData.imageUrl = newUrl;
					return;
				}

        // 如果路径中没有static，尝试提取output目录下的文件
        if (normalizedPath.includes('/output/')) {
          const outputPath = normalizedPath.split('/output/')[1];
          const newUrl = `${baseUrl}/output/${outputPath}`;
          console.log('转换为网络URL (仅文件名):', newUrl);
          this.resultData.imageUrl = newUrl;
          return;
        }

				// 如果路径中没有static，尝试直接构造URL
				// 提取文件名
				const fileName = normalizedPath.split('/').pop();
				if (fileName) {
					// 假设所有结果图片都在static/images目录下
					const newUrl = `${baseUrl}/static/images/${fileName}`;
					console.log('转换为网络URL (仅文件名):', newUrl);
					this.resultData.imageUrl = newUrl;
					return;
				}

				// 如果上述方法都失败，尝试使用文件系统API
				try {
					const fs = uni.getFileSystemManager();
					fs.readFile({
						filePath: filePath,
						encoding: 'base64',
						success: (res) => {
							// 将base64数据设置为图片的src
							this.resultData.imageUrl = 'data:image/jpeg;base64,' + res.data;
							console.log('成功读取并转换图片为base64');
						},
						fail: (err) => {
							console.error('读取图片文件失败:', err);
							uni.showToast({
								title: '图片加载失败',
								icon: 'none'
							});
						}
					});
				} catch (e) {
					console.error('读取文件异常:', e);
					uni.showToast({
						title: '图片处理异常',
						icon: 'none'
					});
				}
			},

			// 获取防治建议
			getPreventionSuggestions() {
				this.isLoadingSuggestions = true;
				// 清空之前的建议，显示初始消息
				this.preventionSuggestions = ["正在生成防治建议..."];

				// 构建提示语
				let prompt = "我是一名农业专家，请根据以下害虫或疾病的识别结果，提供详细的防治措施建议：\n\n";

				// 添加识别结果
				this.resultData.results.forEach((result, index) => {
					prompt += `${index + 1}. ${result.chinese_name || result.name}（置信度：${(result.confidence * 100).toFixed(2)}%）\n`;
				});

				prompt += "\n请提供针对性的防治措施，包括物理防治、生物防治和化学防治方法，以及预防措施。回答格式为：\n1. [第一条建议]\n2. [第二条建议]\n...";

				console.log('DeepSeek提示语:', prompt);

				// 构建请求体
				const requestBody = {
					model: deepseekConfig.model,
					messages: [
						{
							role: "system",
							content: deepseekConfig.systemPrompt
						},
						{
							role: "user",
							content: prompt
						}
					],
					temperature: deepseekConfig.temperature,
					max_tokens: deepseekConfig.maxTokens,
					stream: false // 在uni-app中不使用流式响应
				};

				// 使用uni.request发送请求
				uni.request({
					url: deepseekConfig.apiUrl,
					method: 'POST',
					header: {
						'Content-Type': 'application/json',
						'Authorization': `Bearer ${deepseekConfig.apiKey}`
					},
					data: requestBody,
					success: (res) => {
						console.log('DeepSeek API响应:', res.data);
						if (res.data && res.data.choices && res.data.choices[0]) {
							// 解析响应，获取内容
							const content = res.data.choices[0].message.content;

							// 模拟流式响应效果
							this.simulateStreamResponse(content);
						} else {
							console.error('DeepSeek API响应格式错误:', res.data);
							this.preventionSuggestions = [
								"获取防治建议失败，请稍后再试。",
								"1. 加强田间管理，及时清除杂草",
								"2. 合理使用生物农药进行防治",
								"3. 定期检查作物生长情况"
							];
							this.isLoadingSuggestions = false;
						}
					},
					fail: (err) => {
						console.error('调用DeepSeek API失败:', err);
						this.preventionSuggestions = [
							"获取防治建议失败，请稍后再试。",
							"1. 加强田间管理，及时清除杂草",
							"2. 合理使用生物农药进行防治",
							"3. 定期检查作物生长情况"
						];
						this.isLoadingSuggestions = false;
					}
				});
			},

			// 模拟流式响应效果
			simulateStreamResponse(content) {
				// 将内容分成多个部分
				const contentLength = content.length;
				const chunkSize = Math.max(20, Math.floor(contentLength / 10)); // 分成约10个部分
				let currentPosition = 0;
				let fullContent = "";

				// 清除之前的建议
				this.preventionSuggestions = ["正在生成防治建议..."];

				// 使用定时器模拟流式接收
				const streamInterval = setInterval(() => {
					// 如果已经处理完所有内容，清除定时器
					if (currentPosition >= contentLength) {
						clearInterval(streamInterval);
						this.isLoadingSuggestions = false;
						return;
					}

					// 获取下一个内容块
					const endPosition = Math.min(currentPosition + chunkSize, contentLength);
					const chunk = content.substring(currentPosition, endPosition);
					currentPosition = endPosition;

					// 累加内容
					fullContent += chunk;

					// 更新UI
					const suggestions = this.parseSuggestions(fullContent);
					if (suggestions.length > 0) {
						this.preventionSuggestions = suggestions;
					} else {
						// 如果还没有解析出建议，显示原始内容
						this.preventionSuggestions = [fullContent];
					}
				}, 200); // 每200毫秒更新一次
			},

			// 解析DeepSeek返回的建议内容
			parseSuggestions(content) {
				// 清理Markdown符号
				let cleanedContent = content
					.replace(/\*\*/g, '') // 移除加粗符号 **
					.replace(/\*/g, '')   // 移除斜体符号 *
					.replace(/#+\s/g, '')  // 移除标题符号 # ## ###
					.replace(/`/g, '')     // 移除代码符号 `
					.replace(/>/g, '')     // 移除引用符号 >
					.replace(/\[|\]/g, ''); // 移除链接符号 []

				// 按行分割
				const lines = cleanedContent.split('\n');

				// 过滤出非空行
				const nonEmptyLines = lines.filter(line => line.trim() !== '');

				// 处理结果数组
				let processedLines = [];
				let currentSection = '';

				// 处理每一行
				nonEmptyLines.forEach(line => {
					const trimmedLine = line.trim();

					// 检查是否是标题行（不以数字开头的短句）
					if (trimmedLine.length < 50 && !(/^\d+\./).test(trimmedLine) && !trimmedLine.endsWith('：') && !trimmedLine.endsWith(':')) {
						// 如果当前有积累的内容，先添加到结果中
						if (currentSection) {
							processedLines.push(currentSection);
							currentSection = '';
						}
						// 添加标题行
						processedLines.push(trimmedLine);
					}
					// 检查是否是列表项（以数字开头）
					else if (/^\d+\./.test(trimmedLine)) {
						// 如果当前有积累的内容，先添加到结果中
						if (currentSection) {
							processedLines.push(currentSection);
							currentSection = '';
						}
						// 添加列表项，保留数字编号
						processedLines.push(trimmedLine);
					}
					// 其他内容视为普通段落
					else {
						// 如果是空的，直接添加这一行
						if (!currentSection) {
							currentSection = trimmedLine;
						}
						// 否则，添加到当前段落，用空格连接
						else {
							currentSection += ' ' + trimmedLine;
						}
					}
				});

				// 添加最后一个段落（如果有）
				if (currentSection) {
					processedLines.push(currentSection);
				}

				return processedLines.length > 0 ? processedLines : nonEmptyLines;
			},

			// 判断是否为标题行
			isSuggestionTitle(text) {
				// 标题通常较短，不以数字开头，不以冒号结尾
				return text.length < 50 &&
					!(/^\d+\./).test(text) &&
					!text.endsWith('：') &&
					!text.endsWith(':');
			},

			// 判断是否为列表项
			isSuggestionListItem(text) {
				// 列表项通常以数字+点开头
				return /^\d+\./.test(text);
			}
		}
	}
</script>

<style>
	.container {
		display: flex;
		flex-direction: column;
		align-items: center;
		padding: 30rpx;
		box-sizing: border-box;
		min-height: 100vh;
		background-color: #f8f8f8;
	}

	.title {
		font-size: 24px;
		font-weight: bold;
		color: #0AA344;
		margin-bottom: 30rpx;
		margin-top: 20rpx;
	}

	.image-container {
		width: 100%;
		display: flex;
		justify-content: center;
		margin-bottom: 30rpx;
	}

	.result-image {
		width: 600rpx;
		height: 400rpx;
		border-radius: 16rpx;
		box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
	}

	.info-card {
		width: 100%;
		background-color: #ffffff;
		border-radius: 16rpx;
		padding: 30rpx;
		margin-bottom: 30rpx;
		box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.05);
	}

	.info-header {
		border-bottom: 1px solid #f0f0f0;
		padding-bottom: 20rpx;
		margin-bottom: 20rpx;
	}

	.info-title {
		font-size: 18px;
		font-weight: bold;
		color: #333;
	}

	.info-item {
		display: flex;
		margin-bottom: 20rpx;
		align-items: center;
	}

	.label {
		font-weight: bold;
		width: 150rpx;
		color: #666;
	}

	.value {
		flex: 1;
		color: #333;
	}

	.suggestion-content {
		display: flex;
		flex-direction: column;
		padding: 10rpx;
	}

	.suggestion-item {
		margin-top: 15rpx;
		color: #333;
		line-height: 1.6;
	}

	.suggestion-title {
		font-size: 18px;
		font-weight: bold;
		color: #0AA344;
		margin-top: 30rpx;
		margin-bottom: 20rpx;
		padding-bottom: 10rpx;
		border-bottom: 1px solid #f0f0f0;
	}

	.suggestion-list-item {
		padding-left: 20rpx;
		margin-bottom: 20rpx;
		position: relative;
		font-size: 16px;
	}

	.suggestion-paragraph {
		text-indent: 2em;
		margin-bottom: 20rpx;
		text-align: justify;
		font-size: 16px;
		color: #444;
	}

	.button-group {
		display: flex;
		justify-content: space-between;
		width: 100%;
		margin-top: 40rpx;
	}

	.action-btn {
		width: 45%;
		border-radius: 40rpx;
		font-size: 16px;
		padding: 10rpx 0;
	}

	.share-btn {
		background-color: #0AA344;
		color: white;
	}

	.back-btn {
		background-color: #f0f0f0;
		color: #333;
	}
</style>
