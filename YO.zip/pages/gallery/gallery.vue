<template>
	<view class="container">
		<view class="title">林业害虫图鉴</view>

		<!-- 昆虫列表 -->
		<view class="insect-list">
			<view class="insect-item" v-for="(insect, index) in insects" :key="index" @click="openDetail(insect.name)">
				<image class="insect-image" :src="insect.image" mode="aspectFit"></image>
				<view class="insect-info">
					<view class="insect-name">{{insect.name}}</view>
					<view class="insect-prevention">{{insect.prevention}}</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				insects: [
					{
						name: '二星蝽',
						image: '/static/book/二星蝽.png',
						intro: '二星蝽是一种常见的农业害虫，主要危害多种农作物。',
						habit: '二星蝽一年发生2-3代，以成虫在杂草、落叶下越冬。成虫和若虫均吸食植物汁液。',
						prevention: '(1)成虫集中越冬或出蜇后集中为害时，利用成虫的假死性，震动植株，使虫落地，迅速收集杀死。\n(2)发生严重的喷洒20%灭多威乳油1500倍液。'
					},
					{
						name: '云斑天牛',
						image: '/static/book/云斑天牛.png',
						intro: '云斑天牛是重要的林木蛀干害虫，危害多种阔叶树。',
						habit: '2-3年完成1代，以幼虫在树干内越冬。成虫5-7月出现，有趋光性。',
						prevention: '人工捕杀成虫：成虫发生盛期，要经常检查，利用成虫有趋光性、不喜飞翔、行动慢、受惊后发出声音的特点，傍晚持灯诱杀，或早晨人工捕捉。\n' +
                '2.\n' +
                '杀灭卵和初孵幼虫：成虫产卵期，检查成虫产卵刻槽或流黑水的地方，寻找卵粒．用刀挖或用锤子等物将卵砸死。于卵孵化盛期，在产卵刻槽处涂抹50%辛硫磷乳油5-10倍药液，以杀死初孵化出的幼虫。\n' +
                '3.\n' +
                '消灭危害盛期幼虫：在幼虫蛀干危害期，发现树干上有粪屑排出时，用刀将皮剥开挖出幼虫；或从发现的虫孑L注入50%敌敌畏乳油100倍液，而后用泥将洞口封闭，也可用药泥或浸药棉球堵塞、封严虫孔，毒杀干内害虫。用铁丝插入虫道内刺死幼虫，或用铁丝先将虫道内虫粪勾出，再用磷化铝毒签塞入云班天牛侵入孔，用泥封死，对成虫、幼虫熏杀效果显著。'
					},
					{
						name: '光肩星天牛',
						image: '/static/book/光肩星天牛.png',
						intro: '光肩星天牛是危害杨、柳等树木的主要蛀干害虫。',
						habit: '1-2年完成1代，以幼虫在树干内越冬。成虫6-8月出现，喜食嫩枝皮。',
						prevention: '根据光肩星天牛发生规律、生活习性及在特克斯县发生危害的实际情况，在不同的虫期需采用不同防治方法。成虫期采用人工振落捕杀或药剂喷雾防治；幼虫期采取打孔注药、农业措施破坏栖息场所；以及采取清除疫木、利用天敌、加强植物检疫、营造混交林等综合防治方法，可有效控制光肩星天牛的大面积发生和危害。'
					},
					{
						name: '茶翅蝽',
						image: '/static/book/茶翅蝽.png',
						intro: '茶翅蝽是一种杂食性害虫，危害多种果树和农作物。',
						habit: '一年发生1-2代，以成虫在建筑物缝隙、树皮下越冬。成虫和若虫均吸食植物汁液。',
						prevention: '生物防治\n' +
                '茶翅蝽的寄生性天敌主要是卵寄生蜂，卵寄生蜂这一重要的天敌在害虫生物防治中广为应用，由于其受寄主卵壳的保护从而可以减少杀虫剂对其毒害，并且孵化后可以立即吸吮卵黄规避有毒物质的积累，因此成为重要的生防作用物。在茶翅蝽的新入侵地缺乏有效的天敌，加拿大本土的寄生蜂等足黑卵蜂和瑞士的黄足沟卵蜂。虽然可以将卵产在茶翅蝽卵块内，但并不能成功的完成生长发育。因此传统生物防治(classicalbiologicalcontml)将是控制茶翅蝽行之有效的方法，即从茶翅蝽的原产地区引进其天敌，在新入侵地的农田或自然生态系统中释放并建立种群，达到控制该害虫的目的。总结现有的文献报道，茶翅蝽原产地的卵寄生蜂共有16种，另外还有1种寄蝇可寄生茶翅蝽的成虫。 [1]\n' +
                '化学防治\n' +
                '目前，化学防治是用于茶翅蝽防治的主要方法。在茶翅蝽的新入侵地，拟除虫菊酯和新烟碱类广谱性杀虫剂被广泛采用。田间使用硫丹，灭多威，噻虫嗪和联苯菊酯都对茶翅蝽具有高致死率，但甲氰菊酯fenpmpathrin和呋虫胺只是起到了抑制取食的作用。我们也可以利用茶翅蝽的假死性进行人工防治，气温<23℃时茶翅蝽初显假死行为，然后随温度渐降而加深；突然的声、光干扰能使其假死坠落，假死深度与气温下降和干扰源功率呈正相关。选择气温<21℃的适宜日时段，以棒击震树落虫，地面喷药触杀，可取得高效、安全的防治效果。此外，还可以利用该虫聚集越冬的习性，采用"陷阱"等有效的诱集工具，集中诱杀'
					},
					{
						name: '黑蚱蝉',
						image: '/static/book/黑蚱蝉.png',
						intro: '黑蚱蝉是常见的蝉类昆虫，幼虫期危害植物根系。',
						habit: '多年完成1代，以若虫在土壤中越冬。成虫6-8月出现，雄虫鸣声洪亮。',
						prevention: '人工捕捉出土若虫\n' +
                '在老熟若虫出土始期，在果园及周围所有树木主干中下部缠绕5厘米左右的塑料胶带，或包扎1圈宽5-10厘米的塑料薄膜，阻止若虫上树。然后在若虫出土期内每天夜间或清晨捕捉出土若虫或刚羽化的成虫。 [4]\n' +
                '灯火诱杀\n' +
                '利用成虫较强的趋光性，夜晚在果园空旷处点火堆或用强光灯照明，或黑光灯诱杀，然后振动树枝，使成虫飞向火堆或强光处进行捕杀'
					}
				]
			}
		},
		methods: {
			// 打开详情页面
			openDetail(insectName) {
				// 查找对应的昆虫数据
				const insect = this.insects.find(item => item.name === insectName);
				if (insect) {
					// 将昆虫数据传递到lib页面
					uni.navigateTo({
						url: `/pages/lib/lib?insect=${encodeURIComponent(JSON.stringify(insect))}`
					});
				}
			}
		}
	}
</script>

<style>
	.container {
		display: flex;
		flex-direction: column;
		padding: 30rpx;
		box-sizing: border-box;
		background-color: #C0EBD7;
		min-height: 100vh;
	}

	.title {
		font-size: 28px;
		font-weight: bold;
		color: #0AA344;
		margin-bottom: 50rpx;
		text-align: center;
		margin-top: 30rpx;
		text-shadow: 2rpx 2rpx 4rpx rgba(0, 0, 0, 0.1);
		letter-spacing: 2rpx;
	}

	.insect-list {
		width: 100%;
	}

	.insect-item {
		display: flex;
		background-color: #FFFFFF;
		border-radius: 20rpx;
		padding: 25rpx;
		margin-bottom: 35rpx;
		box-shadow: 0 4rpx 15rpx rgba(0, 0, 0, 0.08);
		transition: all 0.3s ease;
	}

	.insect-item:active {
		transform: scale(0.98);
		box-shadow: 0 2rpx 8rpx rgba(0, 0, 0, 0.05);
	}

	.insect-image {
		width: 220rpx;
		height: 220rpx;
		border-radius: 15rpx;
		object-fit: cover;
		box-shadow: 0 2rpx 8rpx rgba(0, 0, 0, 0.1);
	}

	.insect-info {
		flex: 1;
		padding-left: 35rpx;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}

	.insect-name {
		font-size: 20px;
		font-weight: bold;
		color: #333;
		margin-bottom: 25rpx;
		border-bottom: 2rpx solid #e8e8e8;
		padding-bottom: 10rpx;
	}

	.insect-prevention {
		font-size: 15px;
		color: #555;
		line-height: 1.6;
		max-height: 220rpx;
		overflow-y: auto;
		padding-right: 10rpx;
	}
</style>
