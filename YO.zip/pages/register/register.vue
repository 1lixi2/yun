<template>
  <view class="container">
    <view class="header">
      <text class="title">注册账号</text>
    </view>

    <view class="form">
      <view class="form-item">
        <text class="label">用户名</text>
        <input
          class="input"
          v-model="form.username"
          placeholder="请输入用户名(4-16位字母数字)"
          maxlength="16"
        />
      </view>

      <view class="form-item">
        <text class="label">手机号</text>
        <input
          class="input"
          v-model="form.phone"
          placeholder="请输入手机号"
          type="number"
          maxlength="11"
        />
      </view>

      <view class="form-item">
        <text class="label">密码</text>
        <input
          class="input"
          v-model="form.password"
          type="password"
          placeholder="请输入密码(6-20位)"
          maxlength="20"
        />
      </view>

      <view class="form-item">
        <text class="label">确认密码</text>
        <input
          class="input"
          v-model="form.confirmPassword"
          type="password"
          placeholder="请再次输入密码"
          maxlength="20"
        />
      </view>

      <button class="submit-btn" @click="handleRegister">注册</button>
    </view>

    <view class="footer">
      <text class="login-text">已有账号？</text>
      <text class="login-link" @click="navigateToLogin">去登录</text>
    </view>
  </view>
</template>

<script>
import { useUserStore } from '@/store/user'

export default {
  data() {
    return {
      form: {
        username: '',
        phone: '',
        password: '',
        confirmPassword: ''
      }
    }
  },
  methods: {
    navigateToLogin() {
      uni.navigateTo({
        url: '/pages/index/index'
      })
    },
    validateForm() {
      if (!this.form.username || !this.form.phone || !this.form.password) {
        uni.showToast({
          title: '请填写完整信息',
          icon: 'none'
        })
        return false
      }

      if (!/^[a-zA-Z0-9]{4,16}$/.test(this.form.username)) {
        uni.showToast({
          title: '用户名需4-16位字母数字',
          icon: 'none'
        })
        return false
      }

      if (!/^1[3-9]\d{9}$/.test(this.form.phone)) {
        uni.showToast({
          title: '请输入正确的手机号',
          icon: 'none'
        })
        return false
      }

      if (this.form.password.length < 6) {
        uni.showToast({
          title: '密码至少6位',
          icon: 'none'
        })
        return false
      }

      if (this.form.password !== this.form.confirmPassword) {
        uni.showToast({
          title: '两次密码输入不一致',
          icon: 'none'
        })
        return false
      }

      return true
    },
    async handleRegister() {
      console.log('注册按钮点击事件触发')

      // 详细表单验证日志
      const isValid = this.validateForm()
      console.log('表单验证结果:', isValid)
      if (!isValid) {
        console.log('表单验证未通过，停止注册流程')
        return
      }

      uni.showLoading({
        title: '注册中...',
        mask: true
      })
      console.log('显示加载中状态')

      try {
        console.log('正在提交注册表单:', JSON.stringify(this.form, null, 2))

        // 构建JSON数据
        const postData = {
          username: this.form.username,
          phone: this.form.phone,
          password: this.form.password
        }

        // 发送JSON请求到后端
        const response = await uni.request({
          url: 'http://localhost:5000/register',
          method: 'POST',
          data: postData,
          header: {
            'Content-Type': 'application/json'
          }
        })

        console.log('注册响应:', response)

        // 兼容处理不同环境下的响应结构
        let resData = {}
        if (Array.isArray(response)) {
          // uni-app标准响应结构 [error, res]
          const [error, res] = response
          if (error) {
            console.error('请求错误:', error)
            throw new Error(error.errMsg || '网络请求失败')
          }
          resData = res.data || {}
        } else {
          // 其他可能的响应结构
          resData = response.data || {}
        }

        console.log('注册响应数据:', resData)

        if (resData.status === 'success') {
          uni.showToast({
            title: resData.message || '注册成功',
            icon: 'success'
          })

          setTimeout(() => {
            uni.redirectTo({
              url: '/pages/index/index'
            })
          }, 1500)
          return
        }

        throw new Error(resData.message || '注册失败: 服务器返回异常')
      } catch (error) {
        console.error('注册过程中发生错误:', error)
        uni.showToast({
          title: error.message || '注册失败: 请检查网络连接或联系管理员',
          icon: 'none',
          duration: 3000
        })
      } finally {
        uni.hideLoading()
      }
    }
  }
}
</script>

<style>
.container {
  padding: 40px 20px;
}

.header {
  margin-bottom: 40px;
}

.title {
  font-size: 24px;
  font-weight: bold;
  color: #333;
}

.form-item {
  margin-bottom: 20px;
}

.label {
  display: block;
  margin-bottom: 8px;
  font-size: 14px;
  color: #666;
}

.input {
  width: 100%;
  height: 44px;
  padding: 0 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 16px;
}

.submit-btn {
  width: 100%;
  height: 44px;
  margin-top: 20px;
  background-color: #1890ff;
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 16px;
}

.footer {
  margin-top: 20px;
  text-align: center;
}

.login-text {
  font-size: 14px;
  color: #666;
}

.login-link {
  font-size: 14px;
  color: #1890ff;
  margin-left: 5px;
}
</style>
