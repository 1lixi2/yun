<template>
	<view class="container">
		<view class="header">
			<view class="title">{{insect.name}}</view>
			<image class="insect-image" :src="insect.image" mode="aspectFit"></image>
		</view>

		<view class="content">
			<view class="section">
				<view class="section-title">简介</view>
				<view class="section-content">{{insect.intro || '暂无简介信息'}}</view>
			</view>

			<view class="section">
				<view class="section-title">生活习性</view>
				<view class="section-content">{{insect.habit || '暂无生活习性信息'}}</view>
			</view>

			<view class="section">
				<view class="section-title">防治方法</view>
				<view class="section-content">{{insect.prevention}}</view>
			</view>
		</view>

		<view class="footer">
			<button class="learn-more" @click="openBaidu">了解更多</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				insect: {
					name: '',
					image: '',
					intro: '',
					habit: '',
					prevention: ''
				}
			}
		},
		onLoad(options) {
			if (options.insect) {
				this.insect = JSON.parse(decodeURIComponent(options.insect))
			}
		},
		methods: {
			openBaidu() {
				const searchUrl = `https://baike.baidu.com/search/word?word=${encodeURIComponent(this.insect.name)}`;

				// #ifdef APP-PLUS
				plus.runtime.openURL(searchUrl);
				// #endif

				// #ifdef H5
				window.open(searchUrl, '_blank');
				// #endif

				// #ifdef MP
				uni.showModal({
					title: '提示',
					content: '小程序环境无法直接打开外部链接，请复制链接在浏览器中打开',
					showCancel: false
				});
				// #endif
			}
		}
	}
</script>

<style>
	.container {
		display: flex;
		flex-direction: column;
		padding: 30rpx;
		box-sizing: border-box;
		background-color: #C0EBD7;
		min-height: 100vh;
	}

	.header {
		display: flex;
		flex-direction: column;
		align-items: center;
		margin-bottom: 40rpx;
	}

	.title {
		font-size: 28px;
		font-weight: bold;
		color: #0AA344;
		margin-bottom: 30rpx;
		text-align: center;
	}

	.insect-image {
		width: 300rpx;
		height: 300rpx;
		border-radius: 20rpx;
		object-fit: cover;
		box-shadow: 0 4rpx 15rpx rgba(0, 0, 0, 0.1);
	}

	.content {
		flex: 1;
	}

	.section {
		margin-bottom: 40rpx;
		background-color: #FFFFFF;
		border-radius: 20rpx;
		padding: 25rpx;
		box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.08);
	}

	.section-title {
		font-size: 20px;
		font-weight: bold;
		color: #0AA344;
		margin-bottom: 20rpx;
		border-bottom: 2rpx solid #e8e8e8;
		padding-bottom: 10rpx;
	}

	.section-content {
		font-size: 16px;
		color: #555;
		line-height: 1.8;
	}

	.footer {
		margin-top: 30rpx;
		padding-bottom: 30rpx;
	}

	.learn-more {
		background-color: #0AA344;
		color: #FFFFFF;
		border-radius: 50rpx;
		font-size: 16px;
		height: 80rpx;
		line-height: 80rpx;
	}
</style>
