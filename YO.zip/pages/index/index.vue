<template>
	<view class="container">
		<view class="login-box">
			<view class="title">害虫识别系统，欢迎登录</view>

			<view class="input-group">
				<view class="input-item">
					<text class="label">用户名</text>
					<input class="input" type="text" v-model="username" placeholder="请输入用户名" />
				</view>

				<view class="input-item">
					<text class="label">密码</text>
					<input class="input" type="password" v-model="password" placeholder="请输入密码" />
				</view>

				<button class="login-btn" @click="login">登录</button>

				<button class="register-btn" @click="goToRegister">注册</button>

				<!-- 微信登录按钮 -->
				<view class="other-login">
					<view class="divider">
						<view class="line"></view>
						<text class="text">其他登录方式</text>
						<view class="line"></view>
					</view>
					<view class="wechat-login" @click="wechatLogin">
						<image class="wechat-icon" src="/static/wenchat.png" mode="aspectFit"></image>
						<text class="wechat-text">微信登录</text>
					</view>

					<!-- 离线版入口 -->
					<view class="offline-login" @click="goToOfflineIdentify">
						<image class="offline-icon" src="/static/offline.png" mode="aspectFit"></image>
						<text class="offline-text">使用离线版</text>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				username: '',
				password: '',
				provider: '' // 用于存储服务提供商
			}
		},
		onLoad() {
			console.log('登录页面加载');

			// 检查是否已经登录
			const userInfo = uni.getStorageSync('userInfo');
			const token = uni.getStorageSync('token');

			if (userInfo && token) {
				console.log('检测到用户已登录，准备验证token');
				// 可以在这里验证token是否有效
				// 如果需要自动登录，可以直接跳转到欢迎页面
				// this.autoLogin(userInfo, token);
			}

			// 获取当前平台信息
			try {
				const systemInfo = uni.getSystemInfoSync();
				console.log('当前系统信息:', systemInfo);

				// 根据平台设置不同的UI调整
				if (systemInfo.platform === 'android' || systemInfo.platform === 'ios') {
					// App环境特定设置
					console.log('当前在App环境中运行');
				} else if (systemInfo.platform === 'mp-weixin') {
					// 小程序环境特定设置
					console.log('当前在微信小程序环境中运行');
				} else {
					// H5或其他环境
					console.log('当前在H5或其他环境中运行');
				}
			} catch (e) {
				console.error('获取系统信息失败:', e);
			}

			// 获取服务提供商
			uni.getProvider({
				service: 'oauth',
				success: (res) => {
					console.log('服务提供商列表:', res.provider);
					// 检查是否支持微信登录
					if (res.provider && res.provider.indexOf('weixin') !== -1) {
						this.provider = 'weixin';
						console.log('当前环境支持微信登录');
					} else {
						console.log('当前环境不支持微信登录，可能需要配置相关SDK或权限');
					}
				},
				fail: (err) => {
					console.error('获取服务提供商失败:', err);
					// 即使获取失败，也尝试检测平台
					const platform = uni.getSystemInfoSync().platform;
					if (platform === 'mp-weixin') {
						// 在微信小程序中，即使getProvider失败，也可以使用微信登录
						this.provider = 'weixin';
						console.log('在微信小程序环境中，默认启用微信登录');
					}
				}
			});
		},
		methods: {
			login() {
				// 简单的登录验证
				if (!this.username || !this.password) {
					uni.showToast({
						title: '用户名和密码不能为空',
						icon: 'none'
					});
					return;
				}

				// 显示加载中
				uni.showLoading({
					title: '登录中...'
				});

				// 向后端发送登录请求
				uni.request({
					url: 'http://localhost:5000/login',
					method: 'POST',
					header: {
						'Content-Type': 'application/json'
					},
					data: {
						username: this.username,
						password: this.password
					},
					success: (res) => {
						// 隐藏加载提示
						uni.hideLoading();

						console.log('登录结果:', res.data);

						// 判断登录是否成功
						// 根据后端返回的status字段判断
						if (res.data && res.data.status === 'success') {
							// 存储用户信息和token
							if (res.data.data && res.data.data.user) {
								uni.setStorageSync('userInfo', res.data.data.user);
							}
							if (res.data.token) {
								uni.setStorageSync('token', res.data.token);
							}

							// 显示登录成功提示
							uni.showToast({
								title: '登录成功',
								icon: 'success',
								duration: 1500,
								success: () => {
									// 登录成功后跳转到欢迎页面
									setTimeout(() => {
										uni.reLaunch({
											url: '/pages/welcome/welcome'
										});
									}, 1500);
								}
							});
						} else {
							// 登录失败提示
							uni.showToast({
								title: res.data && res.data.message ? res.data.message : '登录失败',
								icon: 'none'
							});
						}
					},
					fail: (err) => {
						// 隐藏加载提示
						uni.hideLoading();

						console.error('登录请求失败:', err);
						uni.showToast({
							title: '网络请求失败',
							icon: 'none'
						});
					}
				});
			},
			// 微信登录方法 - 直接跳转
			wechatLogin() {
				// 显示登录成功提示
				uni.showToast({
					title: '微信登录成功',
					icon: 'success',
					duration: 1500,
					success: () => {
						// 直接跳转到欢迎页
						setTimeout(() => {
							uni.reLaunch({
								url: '/pages/welcome/welcome'
							});
						}, 1500);
					}
				});
			},

			// 跳转到注册页面
			goToRegister() {
				uni.navigateTo({
					url: '/pages/register/register'
				});
			},

			// 跳转到离线识别页面
			goToOfflineIdentify() {
				uni.navigateTo({
					url: '/pages/identify/offline-identify'
				});
			}
		}
	}
</script>

<style>
	.container {
		padding: 0;
		margin: 0;
		width: 100%;
		height: 100vh;
		background-color: #057748;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.login-box {
		width: 80%;
		padding: 30px;
		background-color: #ffffff;
		border-radius: 10px;
		box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
		animation: fadeIn 0.8s ease-in-out;
	}

	@keyframes fadeIn {
		from {
			opacity: 0;
			transform: translateY(20px);
		}
		to {
			opacity: 1;
			transform: translateY(0);
		}
	}

	.title {
		font-size: 24px;
		color: #424C50;
		text-align: center;
		margin-bottom: 30px;
		font-weight: bold;
	}

	.input-group {
		margin-top: 20px;
	}

	.input-item {
		margin-bottom: 20px;
	}

	.label {
		display: block;
		font-size: 16px;
		color: #424C50;
		margin-bottom: 8px;
	}

	.input {
		width: 100%;
		height: 45px;
		border: 1px solid #ddd;
		border-radius: 5px;
		padding: 0 15px;
		font-size: 16px;
		color: #424C50;
		background-color: #f9f9f9;
		transition: all 0.3s ease;
	}

	.input:focus {
		border-color: #057748;
		box-shadow: 0 0 5px rgba(5, 119, 72, 0.2);
		background-color: #ffffff;
	}

	.login-btn {
		width: 100%;
		height: 45px;
		background-color: #057748;
		color: #ffffff;
		border: none;
		border-radius: 5px;
		font-size: 18px;
		margin-top: 20px;
		box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
		transition: all 0.3s ease;
	}

	.login-btn:active {
		transform: scale(0.98);
		background-color: #046a3f;
	}

	/* 其他登录方式样式 */
	.other-login {
		margin-top: 30px;
	}

	.divider {
		display: flex;
		align-items: center;
		margin-bottom: 20px;
	}

	.line {
		flex: 1;
		height: 1px;
		background-color: #ddd;
	}

	.text {
		padding: 0 15px;
		font-size: 14px;
		color: #999;
	}

	.wechat-login {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		cursor: pointer;
		padding: 10px;
		transition: all 0.3s ease;
	}

	.wechat-login:active {
		transform: scale(0.95);
	}

	.wechat-icon {
		width: 50px;
		height: 50px;
		margin-bottom: 8px;
		border-radius: 50%;
		box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
		padding: 5px;
		background-color: #f5f5f5;
	}

	.wechat-text {
		font-size: 14px;
		color: #07C160;
		font-weight: 500;
	}

	/* 离线版入口样式 */
	.offline-login {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		cursor: pointer;
		padding: 10px;
		transition: all 0.3s ease;
		margin-top: 15px;
	}

	.offline-login:active {
		transform: scale(0.95);
	}

	.offline-icon {
		width: 50px;
		height: 50px;
		margin-bottom: 8px;
		border-radius: 50%;
		box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
		padding: 5px;
		background-color: #f5f5f5;
	}

	.offline-text {
		font-size: 14px;
		color: #0AA344;
		font-weight: 500;
	}
</style>
