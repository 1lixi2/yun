// DeepSeek API配置
export const deepseekConfig = {
  apiUrl: 'https://api.deepseek.com/v1/chat/completions',
  apiKey: 'sk-c091196ed79344cfa48341d94f941627',
  model: 'deepseek-chat',
  temperature: 0.7,
  maxTokens: 800,
  systemPrompt: '你是一个专业的林业害虫知识助手，可以回答用户关于林业害虫的各种问题，包括害虫识别、防治方法、生态影响等。请提供准确、专业的回答。'
};
