<template>
	<view>
		<!-- 全局AI聊天组件 -->
		<AiChat />
	</view>
</template>

<script>
	import AiChat from '@/components/AiChat/AiChat.vue';
	import { useUserStore } from '@/store/user'

	export default {
		components: {
			AiChat
		},
		onLaunch: async function() {
			console.warn('当前组件仅支持 uni_modules 目录结构 ，请升级 HBuilderX 到 3.1.0 版本以上！')
			console.log('App Launch')

			// 初始化TensorFlow插件
			global.tf = requirePlugin('tfjsPlugin');
			if(!global.tf) {
				console.error('TensorFlow插件初始化失败');
				return;
			}

			// 显示加载动画
			uni.showLoading({
				title: '加载中...',
				mask: true
			})

			// 延迟确保Pinia初始化完成
			setTimeout(async () => {
				try {
					const userStore = useUserStore()
					const isAuthenticated = await userStore.fetchUser()

					uni.reLaunch({
						url: isAuthenticated ? '/pages/welcome/welcome' : '/pages/index/index'
					})
				} catch (error) {
					console.error('初始化失败:', error)
					uni.reLaunch({
						url: '/pages/index/index'
					})
				} finally {
					uni.hideLoading()
				}
			}, 300)
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style lang="scss">
	/*每个页面公共css */
	@import '@/uni_modules/uni-scss/index.scss';
	/* #ifndef APP-NVUE */
	@import '@/static/customicons.css';
	// 设置整个项目的背景色
	page {
		background-color: #C0EBD7;
	}

	/* #endif */
	.example-info {
		font-size: 14px;
		color: #333;
		padding: 10px;
	}
</style>
