<template>
	<view class="ai-chat-container">
		<!-- 机器人图标 -->
		<view class="robot-icon" @click="navigateToChat">
			<image src="/static/robot.png" mode="aspectFit" class="robot-image"></image>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'AiChat',
		methods: {
			navigateToChat() {
				console.log('点击机器人图标，准备跳转');
				uni.navigateTo({
					url: '/pages/chat/chat',
					success: () => console.log('跳转成功'),
					fail: (err) => console.error('跳转失败:', err)
				});
			}
		}
	}
</script>

<style lang="scss" scoped>
.ai-chat-container {
	position: relative;
	z-index: 9999;

	.robot-icon {
		position: fixed;
		right: 20rpx;
		bottom: 120rpx;
		width: 100rpx;
		height: 100rpx;
		background-color: #ffffff;
		border-radius: 50%;
		box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.2);
		display: flex;
		justify-content: center;
		align-items: center;
		z-index: 10000;

		.robot-image {
			width: 80rpx;
			height: 80rpx;
		}
	}
}
</style>
