import { defineStore } from 'pinia'

export const useUserStore = defineStore('user', {
  state: () => ({
    user: null,
    isAuthenticated: false
  }),
  actions: {
    async login(credentials) {
      try {
        const { username, password } = credentials;
        
        const response = await uni.request({
          url: 'http://localhost:5000/login',
          method: 'GET',
          data: {
            username,
            password
          },
          header: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        });

        // 处理后端返回的重定向响应
        if (response[0].statusCode === 302) {
          // 检查重定向URL是否指向欢迎页
          const redirectUrl = response[0].header.location;
          if (redirectUrl && redirectUrl.includes('welcome')) {
            this.user = { username };
            this.isAuthenticated = true;
            return true; // 登录成功
          }
        }
        
        // 检查是否有错误消息
        if (response[1] && response[1].data) {
          throw new Error(response[1].data.message || '登录失败');
        }
        
        return false;
      } catch (error) {
        console.error('登录失败:', error);
        throw error; // 向上抛出错误，让调用者处理
      }
    },

    async register(userData) {
      try {
        console.log('开始注册流程，用户数据:', userData);
        const { username, phone, password } = userData;

        // 使用URLSearchParams构建表单数据
        const formData = new URLSearchParams();
        formData.append('username', username);
        formData.append('phone', phone);
        formData.append('password', password);

        const response = await uni.request({
          url: 'http://localhost:5000/register',
          method: 'POST',
          data: formData.toString(),
          header: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        });

        console.log('注册请求响应:', response);

        // 处理后端返回的重定向响应
        if (response[0].statusCode === 302) {
          const redirectUrl = response[0].header.location;
          console.log('重定向URL:', redirectUrl);
          
          if (redirectUrl && redirectUrl.includes('login')) {
            console.log('注册成功，重定向到登录页');
            return true;
          }
          throw new Error('注册成功但重定向异常');
        }

        // 处理其他状态码
        if (response[0].statusCode >= 400) {
          throw new Error(`注册失败: 服务器返回状态码 ${response[0].statusCode}`);
        }

        throw new Error('注册失败: 未知错误');
      } catch (error) {
        console.error('注册过程中发生错误:', error);
        throw new Error(`注册失败: ${error.message}`);
      }
    },

    async logout() {
      try {
        const response = await uni.request({
          url: '/logout',
          method: 'GET'
        })

        if (response[1].data.status === 'success') {
          this.user = null
          this.isAuthenticated = false
          return true
        }
        return false
      } catch (error) {
        console.error('登出失败:', error)
        return false
      }
    },

    async fetchUser() {
      try {
        const response = await uni.request({
          url: '/api/user',
          method: 'GET'
        })

        if (response[1].data.status === 'success') {
          this.user = response[1].data.data
          this.isAuthenticated = true
          return true
        }
        return false
      } catch (error) {
        console.error('获取用户信息失败:', error)
        return false
      }
    }
  }
})
