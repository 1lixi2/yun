以下是在 **Windows 系统** 中完成 **YOLOv5 模型离线部署到微信小程序** 的完整实战步骤，涵盖从环境搭建、模型转换到小程序集成全流程，适用于无网络或内网开发场景。

---

### ✅ 第一步：Windows 上准备 YOLOv5 训练/导出环境（可离线）

#### 1. 安装基础工具
- 安装 [Anaconda](https://www.anaconda.com/)
- 安装 [Git](https://git-scm.com/)
- 安装 [Visual Studio 2019](https://visualstudio.microsoft.com/)（带 C++ 开发组件）

#### 2. 创建虚拟环境（离线可用）
```bash
conda create -n yolov5 python=3.8 -y
conda activate yolov5
```

#### 3. 下载 YOLOv5 源码与权重
```bash
git clone https://github.com/ultralytics/yolov5.git
cd yolov5
# 下载 yolov5n.pt 或自训权重
```

#### 4. 安装依赖（可离线打包）
- 在线环境执行：
```bash
pip install -r requirements.txt
pip wheel -r requirements.txt --wheel-dir=wheelhouse
```
- 拷贝 `wheelhouse/` 到无网电脑，执行：
```bash
pip install wheelhouse\*.whl
```


---

### ✅ 第二步：导出 ONNX 模型（Windows）

#### 1. 修改 `export.py` 参数（可选）
```bash
python export.py --weights yolov5n.pt --include onnx --imgsz 320 --device cpu --optimize --simplify
```

#### 2. 输出文件
```
yolov5n.onnx  # 后续用于转换为 TNN 或 TensorFlow Lite
```

---

### ✅ 第三步：Windows 下将 ONNX 转为 TNN 格式（用于微信小程序）

#### 1. 安装 TNN 转换工具（Windows）
- 下载 [TNN Windows 工具包](https://github.com/Tencent/TNN/releases)
- 解压后配置环境变量（`onnx2tnn.exe` 所在路径加入 `PATH`）

#### 2. 执行转换命令
```bash
python onnx2tnn.py yolov5n.onnx -optimize -v v1.0 -o tnn_model
```

#### 3. 输出文件（用于小程序）
```
tnn_model/
├ yolov5n.tnnproto
└ yolov5n.tnnmodel
```

---

### ✅ 第四步：Windows 下构建微信小程序离线包

#### 1. 项目结构（本地离线）
```
miniprogram/
├ model/
│  ├ yolov5n.tnnproto
│  └ yolov5n.tnnmodel
├ utils/
│  ├ tnn.js
│  └ tnn.wasm
├ pages/index/
│  ├ index.js
│  ├ index.wxml
│  └ index.wxss
└ app.js
```

#### 2. 导入 TNN.js（离线）
- 下载 [TNN.js 微信小程序版本](https://github.com/Tencent/TNN/tree/master/examples/miniprogram/tnnjs)
- 将 `tnn.js`、`tnn.wasm` 放入 `utils/`
- 在 `app.js` 中全局引入：
```js
const TNN = require('/utils/tnn.js');
App({ globalData: { TNN } });
```

#### 3. 小程序端推理代码（index.js）
```js
Page({
  async onLoad() {
    this.session = await getApp().globalData.TNN.createSession({
      modelPath: '/model/yolov5n',
      inputShape: [1, 3, 320, 320],
      deviceType: 0
    });
  },

  async detect(imagePath) {
    const input = await this.image2Tensor(imagePath);
    const output = await this.session.run({ input });
    return this.postprocess(output);
  },

  image2Tensor(imgPath) { /* 使用 canvas 读取并归一化 */ },
  postprocess(output) { /* NMS、阈值过滤 */ }
});
```

---

### ✅ 第五步：微信小程序离线打包设置

#### 1. 本地资源打包
- 将 `model/` 和 `utils/` 文件夹全部放入小程序根目录
- 确保 `.tnnmodel`、`.tnnproto` 文件小于 2MB（可用 INT8 量化）

#### 2. 微信开发者工具设置
- 项目设置 → 本地设置 → 勾选：
  - ✅ 不校验合法域名
  - ✅ 增强编译
  - ✅ ES6 转 ES5（兼容旧机型）

---

### ✅ 常见问题（Windows 特有）

| 问题                           | 解决方法                                                     |
| ------------------------------ | ------------------------------------------------------------ |
| `onnx2tnn` 报错找不到 protobuf | 安装 VS2019 + CMake + 编译 protobuf                          |
| 模型文件 > 2MB                 | 使用 INT8 量化（TNN 提供量化工具）                           |
| WASM 加载失败                  | 确保 `tnn.wasm` 与 `tnn.js` 同目录，且未被 `.gitignore` 忽略 |
| 小程序包体积超限               | 使用分包加载或上传时开启“增强编译”                           |

---

### ✅ 总结：Windows 离线部署路线（推荐）

| 步骤       | 工具               | 说明             |
| ---------- | ------------------ | ---------------- |
| 训练/导出  | YOLOv5 + PyTorch   | Windows 本地完成 |
| 转换模型   | onnx → TNN         | 使用 TNN 工具    |
| 小程序推理 | TNN.js + WASM      | 微信原生支持     |
| 离线部署   | 本地模型 + 本地 JS | 无需联网         |

如需使用 `tflite` 替代 `TNN`，可在 Windows 下使用：
```bash
tflite_convert --saved_model_dir saved_model --output_file yolov5n.tflite
```
然后用 TensorFlow.js 的 `tfjs-tflite` 插件加载（需构建 npm 包）。

---

如需我提供你 Windows 下的完整一键脚本或打包模板，可继续提问。