// index.js - 简化版本
// 获取TensorFlow.js插件实例
const plugin = requirePlugin('tensorflowjs');

// 昆虫标签映射
const INSECT_LABELS = [
  {id: 0, chineseName: "二星蝽", latinName: "Eysacoris guttiger"},
  {id: 1, chineseName: "云斑天牛", latinName: "Batocera horsfieldi"},
  {id: 2, chineseName: "光肩星天牛", latinName: "Anoplophora glabripennis"},
  {id: 3, chineseName: "八点广翅蜡蝉", latinName: "Ricaniaspeculum Walker"},
  {id: 4, chineseName: "未知昆虫4", latinName: "Unknown Species 4"},
  {id: 5, chineseName: "墨天牛", latinName: "Monochamus alternatus"},
  {id: 6, chineseName: "小绿叶蝉", latinName: "Empoasca flavescens"},
  {id: 7, chineseName: "扁刺蛾", latinName: "Thosea sinensis"},
  {id: 8, chineseName: "扇舟蛾", latinName: "Clostera anachoreta"},
  {id: 9, chineseName: "斑衣蜡蝉", latinName: "Lycorma delicatula"},
  {id: 10, chineseName: "旋目夜蛾", latinName: "Speiredonia retorta"},
  {id: 11, chineseName: "柳蓝叶甲", latinName: "plagiodera versicolora"},
  {id: 12, chineseName: "桃蛀螟", latinName: "Conogethes punctiferalis"},
  {id: 13, chineseName: "桑天牛", latinName: "Apriona germari"},
  {id: 14, chineseName: "未知昆虫14", latinName: "Unknown Species 14"},
  {id: 15, chineseName: "二尾舟蛾", latinName: "Cerura menciana"},
  {id: 16, chineseName: "二尾舟蛾(幼虫)", latinName: "Cerura menciana(larva)"},
  {id: 17, chineseName: "玉带凤蝶", latinName: "Papilio polytes"},
  {id: 18, chineseName: "白星花金龟", latinName: "Brevitarsis"},
  {id: 19, chineseName: "碧蛾蜡蝉", latinName: "Geisha distinctissima"},
  {id: 20, chineseName: "稻棘缘蝽", latinName: "Cletus punctiger Dallas"},
  {id: 21, chineseName: "红缘灯蛾", latinName: "Amsacta lactinea"},
  {id: 22, chineseName: "红颈天牛", latinName: "Aromia bungii"},
  {id: 23, chineseName: "绿刺蛾", latinName: "Parasa tessellata"},
  {id: 24, chineseName: "绿刺蛾(幼虫)", latinName: "Parasa tessellata(larva)"},
  {id: 25, chineseName: "美国白蛾", latinName: "Hyphantria cunea"},
  {id: 26, chineseName: "茶翅蝽", latinName: "Halyomorpha halys"},
  {id: 27, chineseName: "未知昆虫27", latinName: "Unknown Species 27"},
  {id: 28, chineseName: "菜粉蝶", latinName: "Pieris rapae"},
  {id: 29, chineseName: "蝼蛄", latinName: "Gryllotalpa spps"},
  {id: 30, chineseName: "赤条蝽", latinName: "Graphosoma rubrolineata"},
  {id: 31, chineseName: "麻皮蝽", latinName: "Erthesina fullo"},
  {id: 32, chineseName: "黑蚱蝉", latinName: "Cryptotympana atrata Fabricius"}
];

Page({
  data: {
    imagePath: '', // 图片路径
    isLoading: false, // 加载状态
    results: [], // 识别结果
    modelLoaded: false // 模型加载状态
  },
  
  // 页面加载
  onLoad: function() {
    // 显示提示
    wx.showToast({
      title: '点击下方按钮选择图片',
      icon: 'none',
      duration: 2000
    });
  },
  
  // 选择图片
  chooseImage: function() {
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album'],
      success: (res) => {
        const tempFilePath = res.tempFilePaths[0];
        this.setData({ 
          imagePath: tempFilePath,
          results: [] // 清空之前的结果
        });
        
        // 模拟识别过程
        this.simulateRecognition();
      }
    });
  },
  
  // 拍照
  takePhoto: function() {
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['camera'],
      success: (res) => {
        const tempFilePath = res.tempFilePaths[0];
        this.setData({ 
          imagePath: tempFilePath,
          results: [] // 清空之前的结果
        });
        
        // 模拟识别过程
        this.simulateRecognition();
      }
    });
  },
  
  // 模拟识别过程
  simulateRecognition: function() {
    this.setData({ isLoading: true });
    
    // 模拟处理延迟
    setTimeout(() => {
      // 随机选择3个昆虫作为结果
      const results = [];
      const usedIndices = new Set();
      
      while (results.length < 3) {
        const randomIndex = Math.floor(Math.random() * INSECT_LABELS.length);
        if (!usedIndices.has(randomIndex)) {
          usedIndices.add(randomIndex);
          const insect = INSECT_LABELS[randomIndex];
          const probability = (Math.random() * 30 + 70).toFixed(2); // 70-100之间的随机数
          
          results.push({
            chineseName: insect.chineseName,
            latinName: insect.latinName,
            probability: probability
          });
        }
      }
      
      // 按概率排序
      results.sort((a, b) => parseFloat(b.probability) - parseFloat(a.probability));
      
      this.setData({
        results: results,
        isLoading: false
      });
    }, 1500);
  }
});